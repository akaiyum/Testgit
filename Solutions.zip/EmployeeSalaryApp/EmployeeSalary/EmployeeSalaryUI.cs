﻿using System;
using System.Windows.Forms;

namespace EmployeeSalaryCalculation
{
    public partial class EmployeeSalaryUI : Form
    {
        private Employee myEmployee = null;

        public EmployeeSalaryUI()
        {
            InitializeComponent();
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            myEmployee = new Employee(idTextBox.Text, nameTextBox.Text, emailTextBox.Text);
            double basic = Convert.ToDouble(basicTextBox.Text);
            double medicalPercent = Convert.ToDouble(medicalPercentageTextBox.Text);
            double conveyancePercent = Convert.ToDouble(conveyancePercentageTextBox.Text); 
            Salary employeeSalary = new Salary(basic, medicalPercent, conveyancePercent);
            
            myEmployee.EmployeeSalary = employeeSalary;
            MessageBox.Show(myEmployee.Name + "'s salary information has been saved.");
        }

        private void incrementButton_Click(object sender, EventArgs e)
        {
            double incrementPercentage = Convert.ToDouble(incrementPercentageTextBox.Text);
            if (myEmployee.EmployeeSalary.Increase(incrementPercentage))
            {
               MessageBox.Show(myEmployee.Name + @"'s salary has been increased.");
            }
            else
            {
                MessageBox.Show(@"Operation failed.");
            }
        }

        private void showButton_Click(object sender, EventArgs e)
        {
            noOfIncrementsTextBox.Text = myEmployee.EmployeeSalary.NoOfIncrements.ToString();
            basicShowTextBox.Text = myEmployee.EmployeeSalary.Basic.ToString();
            medicalAmountTextBox.Text = myEmployee.EmployeeSalary.GetMedicalAmount().ToString();
            conveyanceAmountTextBox.Text = myEmployee.EmployeeSalary.GetConveyanceAmount().ToString();
            totalTextBox.Text = myEmployee.EmployeeSalary.GetTotal().ToString();
        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void conveyancePercentageTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void medicalPercentageTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void basicTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void emailTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void nameTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void idTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void incrementPercentageTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void noOfIncrementsTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void totalTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void conveyanceAmountTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void medicalAmountTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void basicShowTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }
    }
}
