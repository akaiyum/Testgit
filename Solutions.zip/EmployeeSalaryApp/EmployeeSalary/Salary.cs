namespace EmployeeSalaryCalculation
{
    public class Salary
    {
        private double basic;
        private double medicalPercent;
        private double conveyancePercent;
        private int noOfIncrements = 0;

        public Salary(double basic, double medicalPercent, double conveyancePercent) : this()
        {
            this.basic = basic;
            this.medicalPercent = medicalPercent;
            this.conveyancePercent = conveyancePercent;
        }

        public Salary()
        {
            noOfIncrements = 0;
        }

        public double GetTotal()
        {
            return (basic + GetMedicalAmount() + GetConveyanceAmount());
        }

        public double Basic
        {
            get { return basic; }
        }

        public int NoOfIncrements
        {
            get { return noOfIncrements; }
        }

        public bool Increase(double percentOfBasic)
        {
            basic = basic + (Basic*percentOfBasic)/100;
            noOfIncrements = noOfIncrements + 1;
            return true;
        }

        public double GetMedicalAmount()
        {
            return (basic * medicalPercent) / 100;
        }

        public double GetConveyanceAmount()
        {
            return (basic * conveyancePercent) / 100;
        }

    }
}