﻿namespace EmployeeSalaryCalculation
{
    public class Employee
    {
        private string id;
        private string name;
        private string email;
        private Salary employeeSalary;

        public Employee(string id, string name, string email)
        {
            this.id = id;
            this.name = name;
            this.email = email;

        }

        public Salary EmployeeSalary
        {
            get { return employeeSalary; }
            set { employeeSalary = value; }
        }

        public string Name
        {
            get { return name; }
        }
    }
}
