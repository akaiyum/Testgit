using System;
using System.Collections.Generic;

namespace StudentDept
{
    public class Department
    {
        private string code;
        private string name;
        private Dictionary<string, Student> students; 

        public Department(string code, string name) : this()
        {
            this.code = code;
            this.name = name;
        }

        public Department()
        {
            students = new Dictionary<string, Student>();
        }

        public string Code
        {
            get { return code; }
        }

        public string Name
        {
            get { return name; }
        }

        public string AddStudent(Student studentObj)
        {
            try
            {
                students.Add(studentObj.RegNo, studentObj);
                return "Student has been saved in dept.";
            }
            catch(ArgumentException exceptionObj)
            {
                return "Student with same registration number already exists in department. So, provided student information is not saved.";
            }
        }

        public List<Student> GetStudentList()
        {
            return new List<Student>(students.Values);
        }
    }
}