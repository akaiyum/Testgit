﻿using System.Windows.Forms;
using System;

namespace CustAccounts_1_To_many
{
    public partial class BankAccountUI : Form
    {
        private Bank aBank = null;

        public BankAccountUI()
        {
            InitializeComponent();
            accountTypeComboBox.DataSource = Enum.GetNames(typeof (AccountType));
            aBank = new Bank();
            customerForSavingAccComboBox.DisplayMember = "Name";
            customerForTransactionComboBox.DisplayMember = "Name";
            customerForReportComboBox.DisplayMember = "Name";
            accountForTransactionComboBox.DisplayMember = "Number";
        }

        private void saveCustomer_Click(object sender, System.EventArgs e)
        {
            Customer aCustomer = new Customer(nationalIdTextBox.Text, nameTextBox.Text, phoneTextBox.Text, presAddressTextBox.Text);
            string msg = aBank.AddCustomer(aCustomer);
            customerForSavingAccComboBox.Items.Add(aCustomer);
            customerForTransactionComboBox.Items.Add(aCustomer);
            customerForReportComboBox.Items.Add(aCustomer);
            MessageBox.Show(msg);
        }

        private void saveAccountInfo_Click(object sender, System.EventArgs e)
        {
            AccountType accType = (AccountType) Enum.Parse(typeof (AccountType), accountTypeComboBox.Text);
            Account anAccount = new Account(accountNumberTextBox.Text, accType);
            Customer selectedCustomer = (Customer) customerForSavingAccComboBox.SelectedItem;
            string msg = selectedCustomer.OpenAccount(anAccount);
            MessageBox.Show(msg);
        }

        private void customerForTransactionComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            Customer selectedCustomer = (Customer) customerForTransactionComboBox.SelectedItem;
            accountForTransactionComboBox.SelectedItem = null;
            accountForTransactionComboBox.SelectedText = null;
            accountForTransactionComboBox.DataSource = selectedCustomer.GetAllAccount();
        }

        private void depositButton_Click(object sender, EventArgs e)
        {
            Account selectedAccount = (Account) accountForTransactionComboBox.SelectedItem;
            double amount = Convert.ToDouble(amountTextBox.Text);
            string msg = selectedAccount.Deposit(amount);
            MessageBox.Show(msg);
        }

        private void withdrawButton_Click(object sender, EventArgs e)
        {
            Account selectedAccount = (Account)accountForTransactionComboBox.SelectedItem;
            double amount = Convert.ToDouble(amountTextBox.Text);
            string msg = selectedAccount.Withdraw(amount);
            MessageBox.Show(msg);
        }

        private void showAccountInfo_Click(object sender, EventArgs e)
        {
            Customer selectedCustomer = (Customer)customerForReportComboBox.SelectedItem;
            string fullMsg = "Customer: " + selectedCustomer.Name + "\nNational Id: " + selectedCustomer.NationalId + "\n";
            fullMsg += fullMsg + "AccNo\tType\tBalance\n";
            foreach (Account anAccount in selectedCustomer.GetAllAccount())
            {
                fullMsg += anAccount.Number + "\t" + anAccount.Type + "\t" + anAccount.Balance + "\n";
            }
            MessageBox.Show(fullMsg);
        }
    }
}
