﻿namespace CustAccounts_1_To_many
{
    public enum AccountType
    {
        Savings,
        Checking
    }
    public class Account
    {
        private string number;
        private AccountType type;
        private double balance = 0;

        public Account(string number, AccountType type)
        {
            this.number = number;
            this.type = type;
        }

        public string Number
        {
            get { return number; }
        }

        public AccountType Type
        {
            get { return type; }
        }

        public double Balance
        {
            get { return balance; }
        }

        public string Withdraw(double amount)
        {
            if (balance - amount >= 0)
            {
                balance -= amount;
                return amount + " taka has been withdrawn.";
            }
            else
            {
                return " No sufficent balance to withdraw.";
            }
        }

        public string Deposit(double amount)
        {
            balance += amount;
            return amount + " taka has been deposited.";
        }
    }
}
