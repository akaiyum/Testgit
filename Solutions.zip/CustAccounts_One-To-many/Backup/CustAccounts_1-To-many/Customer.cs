﻿using System.Collections.Generic;

namespace CustAccounts_1_To_many
{
    public class Customer
    {
        private string nationalId;
        private string name;
        private string phoneOrMobile;
        private string address;
        private List<Account> accounts;

        public Customer(string nationalId, string name, string phoneOrMobile, string address)
        {
            this.nationalId = nationalId;
            this.name = name;
            this.phoneOrMobile = phoneOrMobile;
            this.address = address;
            this.accounts = new List<Account>();
        }

        public string Name
        {
            get { return name; }
        }

        public string NationalId
        {
            get { return nationalId; }
        }

        public string OpenAccount(Account accountObj)
        {
            accounts.Add(accountObj);
            return "Account of " + name + " with number: " + accountObj.Number + " has been opened.";
        }

        public bool SetNationalId(string nationalId)
        {
            if (nationalId.Length == 13)
            {
                this.nationalId = nationalId;
                return true;
            }
            else
            {
                return false;
            }
        }

        public List<Account> GetAllAccount()
        {
            return accounts;
        }
    }
}
