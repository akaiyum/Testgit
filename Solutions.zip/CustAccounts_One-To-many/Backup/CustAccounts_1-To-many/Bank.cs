﻿using System.Collections.Generic;

namespace CustAccounts_1_To_many
{
    public class Bank
    {
        private List<Customer> customers;

        public Bank()
        {
            customers = new List<Customer>();
        }

        public string AddCustomer(Customer customerObj)
        {
            customers.Add(customerObj);
            return customerObj.Name + " has been added.";
        }
    }
}
