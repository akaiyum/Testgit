﻿using System;
using System.Windows.Forms;

namespace AccountApp
{
    public partial class AccountUI : Form
    {
        private Account anAccount;

        public AccountUI()
        {
            InitializeComponent();
        }

        private void createButton_Click(object sender, EventArgs e)
        {
            anAccount = new Account();
            anAccount.number = accountNumberTextBox.Text;
            anAccount.customerName = customerNameTextBox.Text;
        }

        private void depositButton_Click(object sender, EventArgs e)
        {
            if (anAccount != null)
            {
                double amount = Convert.ToDouble(amountTextBox.Text);
                anAccount.Deposit(amount);
                MessageBox.Show("Deposited");
            }
            else
            {
                MessageBox.Show("Please create account first");
            }
        }

        private void reportButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show(anAccount.customerName + " your account no: " + anAccount.number + " and its balance : " +
                            anAccount.balance);
        }

        private void AccountUI_Load(object sender, EventArgs e)
        {

        }
    }
}
