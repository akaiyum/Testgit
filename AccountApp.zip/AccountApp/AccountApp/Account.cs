﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AccountApp
{
    class Account
    {
        public string number;
        public string customerName;
        public double balance;

        public void Deposit(double amount)
        {
            balance += amount;
            //return "Deposited";
        }

        public string Withdraw(double amount)
        {
            if (balance - amount >= 0)
            {
                balance -= amount;
                return "Withdrawn";
            }
            else
            {
                return "No sufficient amount to withdraw money.";
            }
        }
    }
}
