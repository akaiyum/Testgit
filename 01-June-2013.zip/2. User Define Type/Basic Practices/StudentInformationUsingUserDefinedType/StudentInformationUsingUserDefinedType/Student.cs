﻿namespace StudentInformationUsingUserDefinedType
{
    class Student
    {
        public string regNo;
        public string firstName;
        public string lastName;
    }
}
