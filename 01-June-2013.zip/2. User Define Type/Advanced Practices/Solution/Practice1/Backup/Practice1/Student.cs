﻿namespace Practice1
{
    class Student
    {
        public string regNo;
        public string firstName;
        public string lastName;

        public string GetFullName()
        {
            return (firstName + " " + lastName);
        }

    }
}
