﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Practice1
{
    public partial class StudentInformationUI : Form
    {
        
        Student[] students = new Student[3];
        int studentsArrayIndex;

        public StudentInformationUI()
        {
            InitializeComponent();
            InitializeStudentIndex();
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            if (studentsArrayIndex < 3)
            {
                Student studentObj = new Student();
                studentObj.regNo = regNoTextBox.Text;
                studentObj.firstName = firstNameTextBox.Text;
                studentObj.lastName = lastNameTextBox.Text;
                students[studentsArrayIndex] = studentObj;
                studentsArrayIndex++;
                MessageBox.Show("Student with reg no: " + studentObj.regNo + " has been saved.");
            }
            else
            {
                MessageBox.Show("No more student to save");
            }
        }

        private void buttonShowAll_Click(object sender, EventArgs e)
        {
            if (studentsArrayIndex < 3)
            {
                int presentNumberOfStudents = studentsArrayIndex;
                MessageBox.Show("Only " + presentNumberOfStudents + " student(s) has been saved." +
                                (3 - presentNumberOfStudents) + " student(s) is still remaining.");
            }
            else
            {
                string columns = "Registration Number\t" + "Full Name";
                string studentsInformation = "";

                foreach (Student studentObj in students)
                {
                    studentsInformation += studentObj.regNo + "\t";
                    studentsInformation += studentObj.GetFullName();
                    studentsInformation += "\n";
                }
                MessageBox.Show(columns + "\n" + studentsInformation);                
            }
        }

        private void clearAllButton_Click(object sender, EventArgs e)
        {
            InitializeStudentIndex();
            students = new Student[3];
            MessageBox.Show("Students information has been cleared.");
        }

        private void InitializeStudentIndex()
        {
            studentsArrayIndex = 0;
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
