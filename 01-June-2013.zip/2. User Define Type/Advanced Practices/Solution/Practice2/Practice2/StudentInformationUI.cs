﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Practice2
{
    public partial class StudentInformationUI : Form
    {
        
        List<Student> students = new List<Student>();
        public StudentInformationUI()
        {
            InitializeComponent();
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            Student studentObj = new Student();
            studentObj.regNo = regNoTextBox.Text;
            studentObj.firstName = firstNameTextBox.Text;
            studentObj.lastName = lastNameTextBox.Text;
            students.Add(studentObj);
            ClearTextBoxes();
        }

        private void ClearTextBoxes()
        {
            regNoTextBox.Text = "";
            firstNameTextBox.Text = "";
            lastNameTextBox.Text = "";
        }

        private void buttonShowAll_Click(object sender, EventArgs e)
        {
            string columns = "Registration Number " + "Full Name";
            string studentsInformation = "";

            foreach (Student aStudent in students)
            {
                studentsInformation += aStudent.regNo + "\t";
                studentsInformation += aStudent.GetFullName();
                studentsInformation += "\n";
            }

            MessageBox.Show(columns + "\n" + studentsInformation);
        }
    }
}
