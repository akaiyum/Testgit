﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EmployeeInformationUserDefinedType
{
    public class Employee
    {
        public string id;
        public string name;
        public double salary;
    }
}
