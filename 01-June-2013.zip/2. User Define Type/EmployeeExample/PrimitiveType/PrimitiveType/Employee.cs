﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EmployeeInformationPrimitiveType
{
    public class Employee
    {
        public string id;
        public string name;
        public double salary;
        public string address;
        public int age;
    }
}
