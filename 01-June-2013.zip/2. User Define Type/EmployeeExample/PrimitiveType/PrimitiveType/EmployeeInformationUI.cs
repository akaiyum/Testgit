﻿using System;
using System.Windows.Forms;

namespace EmployeeInformationPrimitiveType
{
    public partial class EmployeeInformationUI : Form
    {
          

        public EmployeeInformationUI()
        {
            InitializeComponent();
        }

        Employee employeeVar = new Employee();

        private void retrieveButton_Click(object sender, EventArgs e)
        {
            idTextBox.Text = employeeVar.id;
            nameTextBox.Text = employeeVar.name;
            salaryTextBox.Text = employeeVar.salary.ToString();
        }

        private void showButton_Click(object sender, EventArgs e)
        {
            employeeVar.id = idTextBox.Text;
            employeeVar.name = nameTextBox.Text;
            employeeVar.salary = Convert.ToDouble(salaryTextBox.Text);
            ClearEmployeeInformationFromTextBoxes();
            MessageBox.Show("Employee Information." + "\nId: " + employeeVar.id + 
                "\nName: " + employeeVar.name + "\nSalary: " + employeeVar.salary);

        }

        private void ClearEmployeeInformationFromTextBoxes()
        {
            idTextBox.Text = "";
            nameTextBox.Text = "";
            salaryTextBox.Text = "";
        }

        private void EmployeeInformationUI_Load(object sender, EventArgs e)
        {

        }
    }
}
