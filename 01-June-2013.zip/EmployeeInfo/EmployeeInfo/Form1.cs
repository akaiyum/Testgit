﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EmployeeInfo
{
    public partial class EmployeeInfoUI : Form
    {
        public EmployeeInfoUI()
        {
            InitializeComponent();
            employeeComboBox.DisplayMember = "Name";
        }

        List<Employee> employee = new List<Employee>();

       

       // public List<Employee> employee= new List<Employee>();

        //public int [] id =new int[10];
       // public List<int> id=new List<int>();
       // public string [] name= new string[10];
        //public double[] salary = new double[10];
       // public List<string> name=new List<string>();
       // public List<double> salary=new List<double>();
        public int counter=0;
        public int index=0;
        public double from;
        public double to;
        public int i=0;
        private void saveButton_Click(object sender, EventArgs e)
        {
            Employee employee = new Employee();

            employee.id=Convert.ToInt32(idTextBox.Text);
            employee.name=nameTextBox.Text;
            employee.salary=Convert.ToDouble(salaryTextBox.Text);

            employee.Add(employee);
            employeeComboBox.Items.Add(employee);
            



            /*  employeeComboBox.Items.Add(name[counter]);
            counter++;
            idTextBox.Text = "";
            nameTextBox.Text = "";
            salaryTextBox.Text = "";
            */
        }

        private void retrieveButton_Click(object sender, EventArgs e)
        {

            Employee selectedEmployee = (Employee) employeeComboBox.SelectedIndex;
            /*index  = employeeComboBox.SelectedIndex;
         idTextBox.Text = Convert.ToString(id[index]);
         nameTextBox.Text = name[index];
         salaryTextBox.Text = Convert.ToString(salary[index]);
            */
        }

        private void searchButton_Click(object sender, EventArgs e)
        {
            employeeListBox.Items.Clear();
            from = Convert.ToDouble(fromTextBox.Text);
            to = Convert.ToDouble(toTextBox.Text);
          //for(i=0;i<=counter;i++)
            index = 0;
            foreach (int i in salary)
          
            {
                if(i>=from&& i<=to)
                {
                    
                    employeeListBox.Items.Add(id[index]);
                    index++;
                  

                }
                
            }
          
               
        }

 
       
    }


}
