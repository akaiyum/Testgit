﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace CustomerQueueApp
{
    public partial class CustomerComplainForm : Form
    {
        public CustomerComplainForm()
        {
            InitializeComponent();
        }
        Queue<Customer> customerQueue = new Queue<Customer>();
        private int indexSerial = 1;

        private void enqueueButton_Click(object sender, EventArgs e)
        {
            Customer customerObj = new Customer();
            customerObj.name = nameTextBox.Text;
            customerObj.complain = complainTextbox.Text;

            customerObj.serialNumber = indexSerial.ToString();
            customerQueue.Enqueue(customerObj);
            indexSerial++;
            ListViewItem item = new ListViewItem();
            item.Tag = customerObj;
            item.Text = customerObj.serialNumber;
            item.SubItems.Add(customerObj.name);
            item.SubItems.Add(customerObj.complain);
            remainingCustomerListView.Items.Add(item);
            MessageBox.Show(customerObj.name + @"'s serial number is: " + customerObj.serialNumber);
        }

        private void dequeueButton_Click(object sender, EventArgs e)
        {
            Customer customerObj = new Customer();
            customerObj = customerQueue.Dequeue();
            customerNameTextBox.Text = customerObj.name;
            serialNoTextBox.Text = customerObj.serialNumber;

            customerComplainTextBox.Text = customerObj.complain;

            remainingCustomerListView.Items[0].Remove();
        }

        private void remainingCustomerListView_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
