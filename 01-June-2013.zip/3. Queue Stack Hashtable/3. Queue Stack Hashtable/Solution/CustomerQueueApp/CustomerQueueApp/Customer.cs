﻿namespace CustomerQueueApp
{
    class Customer
    {
        public string serialNumber;
        public string name;
        public string complain;
    }
}
