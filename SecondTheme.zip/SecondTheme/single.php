<?php get_header(); 

/* Template Name: For About Page
*/

     ?>
  <div class="row container-kamn">  
        <img src="<?php echo $page_thumb[0]; ?>" width="100%" class="blog-post" alt="Feature-img" align="right" width="100%"> 

    </div>


<div id="banners"></div>
    <div class="container">   
        <div class="row">
            <div class="col-sm-10 col-md-10">
                 <?php 
                        if (have_posts() ) {
                            while (have_posts() ) {
                                the_post();
                                $post_icon_class = get_post_meta( get_the_ID(),'post_icon_class', true);
                                ?>
            <div class="blog-post">
                        <h1 class="blog-title">
                            <i class="fa <?php echo $post_icon_class;?>"></i>
                            <?php the_title(); ?>
                        </h1>
                        <br>
                        <?php the_post_thumbnail('post-thumb'); ?>
                        <br>
                        <p>
                             <?php the_content(); ?>
                        </p>
                        <div>
                            <span class="badge">Posted <?php echo get_the_date('y-m-d H:i:s'); ?></span>
                            <div class="pull-right">
                                   <?php
                                    the_tags('<span class="label label-default">', '</span> <span class="label label-primary">', '</span>');
                                   ?>
                    
                                
                            </div>         
                        </div>
                    </div>
                    <hr>

                         <?php
                }
            }
            ?>
            </div>
        </div>
    </div>
                
</div>  

    <!--End Main Container -->

  <?php get_footer(); ?>
