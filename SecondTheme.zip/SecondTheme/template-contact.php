<?php
      get_header();
      /*
         Template Name: Contact Template

      */
?>


        <!-- Main Container -->

        <div class="container-fluid-kamn">
            <div class="row">
                <div>
                    <iframe width="100%" height="450px" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="<?php echo $abdul_kaiyum['map_url']; ?>"></iframe>
                    <br />
                </div>
                <div class="col-lg-4 col-lg-offset-1">
                    <h4><?php echo $abdul_kaiyum['contact_text_heading']; ?></h4>
                    <?php echo $abdul_kaiyum['contact_text']; ?>
                    <br>
                    <p class="lead"><?php echo $abdul_kaiyum['social_heading']; ?></p><hr>
                     <?php 
                                 if (is_array($abdul_kaiyum['contact_social_links'])) {
                                        foreach ($abdul_kaiyum['contact_social_links'] as $avalue) {
                                            ?>
                                            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                            <a href="<?php echo $avalue['url']; ?>"><img src="<?php echo $avalue['image']; ?>" alt="Skype"></a>
                                            <?php echo $avalue['title']; ?>
                                           </div>
                                           
                                     <?php   }
                                  
                                 }

                     ?>



                    
                    
                    <br>
                </div>
                <div class="col-lg-5">
                    <div class="feedback-form">
          
                        <div id="contact-response"></div>

                        <?php echo do_shortcode('[contact-form-7 id="191" title="contact form"]'); ?>
                    </div> 
                </div>
            </div>
        </div>    
            
    <!--End Main Container -->


  <?php get_footer(); ?>