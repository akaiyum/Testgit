jQuery(document).ready(function($){
          tinymce.PluginManager.add('my_mce_button', function( editor, url ) {
		editor.addButton('my_mce_button', {
			text: 'Slider',
			icon: false,
			onclick: function() {
				editor.insertContent('[akaiyum_slider]');
			}
		  });
	   });
         tinymce.PluginManager.add('my_mce_button_second', function( editor, url ) {
		editor.addButton('my_mce_button_second', {
			text: 'Slider2',
			icon: false,
			type: 'menubutton',
			menu: [
                    {
                    	text: 'menu first level',
                    	onclick: function() {
				             editor.insertContent('[menu_first_level_1]');
			            }
                    },
                    {
                    	text: 'menu second level',
                    	menu: [
                    	     {
                                  text: 'menu second level 1',
                    	     },
                    	     {
                                  text: 'menu second level 2',
                    	     },

                    	]
                    },
                    {
                    	text: 'menu third level_3',
                    	onclick: function() {
								editor.windowManager.open( {
									title: 'Insert Random Shortcode',
									body: [
										{
											type: 'textbox',
											name: 'firstname',
											label: 'First Name',
											value: 'Linkon'
										},
										{
											type: 'textbox',
											name: 'address',
											label: 'Adress',
											multiline: true,
											minWidth: 300,
											minHeight: 100
										},
										{
											type: 'listbox',
											name: 'selectSex',
											label: 'select your sex',
											'values': [
												{text: 'Male', value: 'male'},
												{text: 'Female', value: 'female'},
											]
										}
									],
									onsubmit: function( e ) {
										editor.insertContent( '[ebit firstName="'+ e.data.firstname +'" address="'+ e.data.address +'" sex="' + e.data.selectSex + '"]');
									}
								});
							}
                    },

			]
		  });
	   });

});
	
(function() {
	
})();