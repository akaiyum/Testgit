<?php

/*
      Template Name: Register Form
*/
      get_header(); ?>
      <section class="register_section" style="padding: 100px 0;">
      	   <div class="container">
      	   		<div class="row">
      	   			<div class="col-md-12">
      	   				<div class="register_form">
<form name="registerform" id="registerform" action="<?php echo site_url(); ?>/wp-login.php?action=register" method="post" novalidate="novalidate">
	<p>
		<label for="user_login">Username<br />
		<input type="text" name="user_login" id="user_login" class="input" value="" size="20" /></label>
	</p>
	<p>
		<label for="user_email">Email<br />
		<input type="email" name="user_email" id="user_email" class="input" value="" size="25" /></label>
	</p>
	
      <p>
        <label for="father">father's name<br />
        <input type="text" name="user_father" id="father" class="input" value="" size="20" /></label>
    </p>
	<p id="reg_passmail">Registration confirmation will be emailed to you.</p>
	<br class="clear" />
	<input type="hidden" name="redirect_to" value="" />
	<p class="submit"><input type="submit" name="wp-submit" id="wp-submit" class="button button-primary button-large" value="Register" /></p>
</form>
      	   				</div>
      	   			</div>
      	   		</div>
      	   </div>
      </section>





 <?php get_footer(); ?>