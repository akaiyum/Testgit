<?php get_header(); ?>

<?php

$sorter_options= $abdul_kaiyum['sorter_options']['Active'];
  if(is_array($sorter_options)){
          foreach ($sorter_options as $key => $bvalue) {
                switch ($key) {
                  case 'slider':
                     get_template_part( 'section-slider');
                    break;
                    case 'service':
                     get_template_part( 'section-service');
                    break;
                    case 'red':
                     get_template_part( 'section-red');
                    break;
                  
                }
              }    
  }
?>

  


  <?php get_footer(); ?>