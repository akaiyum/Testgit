<?php
add_action('init', 'office_muster_custom_post');
function office_muster_custom_post(){
    
        register_post_type('slider',array(
                  'labels' => array (
                    'name' => 'main slider', 
                    'menu_name' => 'slider menu',
                    'all_items' => 'all slider',
                    'add_new' => 'add new slider',
                    'add_new_item' => 'add new slider item'
                        ),
                  'public'=> true,
                  'supports' => array(
                     'title', 'thumbnail', 'revisions', 'custom-fields', 'page-attributes',
                    )

            ));
         register_post_type('service',array(
                  'labels' => array (
                    'name' => 'main service', 
                    'menu_name' => 'service menu',
                    'all_items' => 'all service',
                    'add_new' => 'add new service',
                    'add_new_item' => 'add new service item'
                        ),
                  'public'=> true,
                  'supports' => array(
                     'title', 'revisions', 'custom-fields', 'page-attributes',
                    )

            ));
         register_post_type('team',array(
                  'labels' => array (
                    'name' => 'Team', 
                    'menu_name' => 'Team menu',
                    'all_items' => 'all Team member',
                    'add_new' => 'add new Team member',
                    'add_new_item' => 'add new Team member'
                        ),
                  'public'=> true,
                  'supports' => array(
                     'title', 'revisions', 'page-attributes', 'thumbnail', 'custom-fields'
                    )

            ));

            register_taxonomy(
            'team_category',
            'team',
            array(
                    'labels' => array(
                              'name' => 'Team Category',
                              'add_new_item' => 'Add New Category',
                    ),
                    'hierarchical' => true,
                    'show_admin_column' => true,

                   )
	       );

            register_taxonomy(
            'team_tag',
            'team',
            array(
                    'labels' => array(
                              'name' => 'Team Tag',
                              'add_new_item' => 'Add New Team Tag',

                    ),
                    'show_admin_column' => true,

                   )
	       );

  }



	





