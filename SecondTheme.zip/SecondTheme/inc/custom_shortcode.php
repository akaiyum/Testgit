<?php
function our_slider($para, $content){
     $para = shortcode_atts(array(
           'fz' => '25px',
           'color' => 'red',
     ), $para);
               ob_start(); 

     ?>

<h2 style="color:<?php echo $para['color']; ?>; font-size: <?php echo $para['fz']; ?>; "><?php echo $content; ?></h2>


     <?php
return 

           ob_get_clean();


}



add_shortcode('my_slider', 'our_slider');

function abdul_kaiyum_slider( $atts, $content = null ) {
	
	//[akaiyum_slider]
	
	//get the attributes
	$atts = shortcode_atts(
		array(
         'id'=> 0,
		),
		$atts,
		'akaiyum_slider'
	);
	
	//return HTML
	ob_start();
	include 'akaiyum-slider.php';
	return ob_get_clean();
	
}
add_shortcode( 'akaiyum_slider', 'abdul_kaiyum_slider' );