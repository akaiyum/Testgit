<?php
function ebit_widgets(){
	register_sidebar(array(
        'name' => 'ebit custom sidebar',
        'id' => 'ebit_custom_sidebar'
	));
	register_widget('ebitSlider');
	register_widget('ebitPost');
}



add_action('widgets_init', 'ebit_widgets');
/**
 * 
 */
class ebitSlider extends WP_Widget
{
	public function __construct(){
		parent::__construct(
              'ebitSlider',
              'Ebit SLider',
              array(
                        'description' => 'This widgets for slider'
              )

		);
	}
	public function form($value){
		?>
		<label for="<?php echo $this->get_field_id('sliderID'); ?>">ID</label>
		<input type="text" name="<?php echo $this->get_field_name('slider_id'); ?>" id="<?php echo $this->get_field_id('sliderID'); ?>" value="<?php echo $value['slider_id']; ?>" class="widefat">

		<?php
	}

   public function update( $new, $old){
          $old['slider_id'] = $new['slider_id'];
          return $old;
   }

	

	public function widget($args, $value){
		echo do_shortcode('[akaiyum_slider id="'.$value['slider_id'].'"]');
	}
	
}
class ebitPost extends WP_Widget
{
	public function __construct(){
		parent::__construct(
              'ebitPost',
              'Ebit Post',
              array(
                        'description' => 'This widgets for Post'
              )

		);
	}
	public function form($value){
		?>
		<label for="<?php echo $this->get_field_id('postType'); ?>">Post Type</label>
		<input type="text" name="<?php echo $this->get_field_name('post_type'); ?>" id="<?php echo $this->get_field_id('postType'); ?>" value="<?php echo $value['post_type']; ?>" class="widefat">


		<label for="<?php echo $this->get_field_id('postPerPage'); ?>">Post Per Page</label>
		<input type="text" name="<?php echo $this->get_field_name('post_per_page'); ?>" id="<?php echo $this->get_field_id('postPerPage'); ?>" value="<?php echo $value['post_per_page']; ?>" class="widefat">

		<?php
	}

	
    public function update( $new, $old){
          $old['post_type'] = $new['post_type'];
          $old['post_per_page'] = $new['post_per_page'];
          return $old;
   }
   

	

	public function widget($args, $value){
		$ebit_post = null;
                $ebit_post = new WP_Query(array(
                     'post_type' => $value['post_type'],
                     'posts_per_page' => $value['post_per_page'],

                    ));
                if( $ebit_post->have_posts() ){
                	echo '<ul>';
                    while( $ebit_post->have_posts() ){
                    	 $ebit_post->the_post();

                    echo '<li><a href="'.get_the_permalink().'">'.get_the_title().'</a></li>';

                }
                  echo '<ul>';

                }else{

                    echo"have no post";
                }


                wp_reset_postdata();
               
	}
	
	
}