<?php

/**
 * Get the bootstrap!
 * (Update path to use cmb2 or CMB2, depending on the name of the folder.
 * Case-sensitive is important on some systems.)
 */
require_once __DIR__ . '/cmb2/init.php';


add_action( 'cmb2_admin_init', 'cmb2_sample_metaboxes' );
/**
 * Define the metabox and field configurations.
 */
function cmb2_sample_metaboxes() {

	// Start with an underscore to hide fields from custom fields list
	$pref = '_office-master_';

	/**
	 * Initiate the metabox
	 */
	$service_item = new_cmb2_box( array(
		'id'            => 'service_metabox',
		'title'         => __( 'Service Metabox', 'office_master' ),
		'object_types'  => array( 'service', ), // Post type
		'context'       => 'normal',
		'priority'      => 'high',
		'show_names'    => true, // Show field names on the left
	) );

	// Regular text field
	$service_item->add_field( array(
		'name'       => __( 'Service Icon', 'office_master' ),
		'desc'       => __( 'write here your service icon\'s font aewsome name', 'office_master' ),
		'id'         => $pref.'service_icon',
		'type'       => 'text',
		'repeatable' => true,
			) );

	$about_page_group = new_cmb2_box( array(
		'id'            => 'group_page_metabox',
		'title'         => __( 'Post Metabox', 'office_master' ),
		'object_types'  => array( 'page', ), // Post type
		'context'       => 'normal',
		'priority'      => 'high',
		'show_names'    => true, 
		'show_on'       => array(
			'key' => 'id',
			'value' => 157
		),
	) );

        $about_group_para = $about_page_group -> add_field( array(
		'name'       => __( 'Groupable field', 'Office_muster' ),
		'id'         =>'about_group_meta_field',
		'type'       => 'group',
	     ) );
           $about_page_group -> add_group_field($about_group_para, array(
		'name'       => __( 'Heading field', 'Office_muster' ),
		'id'         =>'heading',
		'type'       => 'text',
	     ) );
           $about_page_group -> add_group_field($about_group_para, array(
		'name'       => __( 'About Description', 'Office_muster' ),
		'id'         =>'about_description',
		'type'       => 'textarea',
	     ) );
           
           
           
           $about_page_group -> add_group_field($about_group_para, array(
		'name'       => __( 'A tag hash title', 'Office_muster' ),
		'id'         =>'hash_link_title',
		'type'       => 'text',
		'repeatable' => true,
	     ) );

           $about_page_group -> add_group_field($about_group_para, array(
		'name'       => __( 'A tag hash link', 'Office_muster' ),
		'id'         => 'hash_link',
		'type'       => 'text',
		'repeatable' => true,
	     ) );
        




}