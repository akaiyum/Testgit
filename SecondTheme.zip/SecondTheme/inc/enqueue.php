<?php
function office_muster_css_js(){
    wp_enqueue_style('google-font-1', '//fonts.googleapis.com/css?family=Open+Sans:400,300', null, 'v1.20', 'all');
    wp_enqueue_style('google-font-2', '//fonts.googleapis.com/css?family=PT+Sans', null, 'v1.30', 'all');
    wp_enqueue_style('google-font-3', '//fonts.googleapis.com/css?family=Raleway', null, 'v1.40', 'all');
    wp_enqueue_style('bootstrap', get_template_directory_uri().'/assets/bootstrap/css/bootstrap.css');
    wp_enqueue_style('font-awesome', get_template_directory_uri().'/assets/css/font-awesome.min.css');
    wp_enqueue_style('theme-style', get_template_directory_uri().'/assets/css/style.css');
    wp_enqueue_style('theme-style', get_template_directory_uri().'/assets/css/style.css');
    wp_enqueue_style('theme-style', get_template_directory_uri().'/assets/css/style.css');
    wp_enqueue_style('anmimate', get_template_directory_uri().'/assets/css/animate.min.css');
    wp_enqueue_style('main_stylesheet', get_stylesheet_uri() );
    wp_enqueue_script('jquery');
    wp_enqueue_script('bootstrap-js', get_template_directory_uri().'/assets/bootstrap/js/bootstrap.min.js', 'jquery', null, true);
    wp_enqueue_script('wow-js', get_template_directory_uri().'/js/wow.min.js', 'jquery', null, true);


}
add_action('wp_enqueue_scripts','office_muster_css_js');
function extra_js(){
    ?>
    <script>
      new WOW().init();
    </script>

    <?php
       
}

add_action('wp_footer','extra_js', 30);