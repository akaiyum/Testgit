<?php
require get_template_directory().'/inc/abdul_kaiyum_theme_support.php';
require get_template_directory().'/inc/enqueue.php';
require get_template_directory().'/inc/custom-post-type.php';
require get_template_directory().'/inc/cmb2-custom-field.php';
require get_template_directory().'/inc/redux-framework-master/redux-framework.php';
require get_template_directory().'/inc/barebones-config.php';
require get_template_directory().'/inc/custom_shortcode.php';
require get_template_directory().'/inc/tinymce-button.php';
require get_template_directory().'/inc/akaiyum-plugin-activation.php';
require get_template_directory().'/inc/custom-widgets.php';




function cExcerpt($number=50, $readmore = 'Read More'){

	$newnumber = $number+1;

	$var = explode(' ', strip_tags(get_the_content()), $newnumber);

	if (count($var) >= $newnumber) {
		array_pop($var);
	}
	array_push($var, '<a href="'.get_the_permalink().'">'.$readmore.'</a>');
	$var = implode(' ', $var);
	return $var;

}
add_action('register_form', 'custom_registration_fields');
function custom_registration_fields(){
    if ( isset($_POST['user_father'])) {
        $father = $_POST['user_father'];
    }else{
        $father = '';
    }
?>

      <p>
        <label for="father">father's name<br />
        <input type="text" name="user_father" id="father" class="input" value="<?php echo $father; ?>" size="20" /></label>
    </p>
<?php
}




add_action('personal_options_update', 'custom_registration_form_save');
add_action('user_register', 'custom_registration_form_save');

function custom_registration_form_save($user_id){
        update_user_meta( $user_id, 'user_father', $_POST['user_father'] );
}
add_action('show_user_profile', 'display_user_custom_data');
add_action('edit_user_profile', 'display_user_custom_data');
function display_user_custom_data($user){
          ?>
                   <table class="form-table">
                       <tr class="user-description-wrap">
                           <th><label for="fathersName">Father's Name:</label></th>
                           <td><input type="text" name="user_father" value="<?php echo get_user_meta($user->ID, 'user_father', true); ?>" class="regular-text code" id="fathersName">
                           </td>
                       </tr>
                   </table> 
          <?php
}



