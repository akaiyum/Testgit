  <!-- Footer -->

    <footer style="background: <?php global $abdul_kaiyum; echo $abdul_kaiyum['footer_top_bg'];?>"> 
        <?php global $abdul_kaiyum; ?>
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h3><i class="fa <?php global $abdul_kaiyum; echo $abdul_kaiyum['col_1_icon']; ?>"></i> <?php global $abdul_kaiyum; echo $abdul_kaiyum['col_1_title']; ?></h3>
                    <?php global $abdul_kaiyum; echo $abdul_kaiyum['col_1_text']; ?>
                </div>
                <div class="col-md-4">
                    <h3><i class="fa <?php global $abdul_kaiyum; echo $abdul_kaiyum['col_2_icon']; ?>"></i> <?php global $abdul_kaiyum; echo $abdul_kaiyum['col_2_title']; ?></h3>

                    <?php
                    if( is_array($abdul_kaiyum['col_2_Links'])){
                     foreach ( $abdul_kaiyum['col_2_Links'] as $singleValue ) {
                         echo '<p> <a href="'.$singleValue['url'].'">'.$singleValue['title'].'</a></p>';
                     }
                 }
                    ?>
                    
                </div>
              <div class="col-md-4">
                <h3><i class="fa <?php global $abdul_kaiyum; echo $abdul_kaiyum['col_3_icon']; ?>"></i> <?php global $abdul_kaiyum; echo $abdul_kaiyum['col_3_title']; ?></h3>
                <div id="social-icons">
                     <?php
                    if( is_array($abdul_kaiyum['col_3_Links'])){
                     foreach ( $abdul_kaiyum['col_3_Links'] as $singleValue ) {
                    ?>
                          <a href="<?php echo $singleValue['url'];?>" class="btn-group">
                            <i class="fa <?php echo $singleValue['title']; ?>"></i>
                          </a>
                   <?php      
                     }
                     }
                    ?>
                </div>
              </div>    
        </div>
      </div>
    </footer>

    
    <div class="copyright text center">
        <?php global $abdul_kaiyum; echo $abdul_kaiyum['copy_txt'];?>
    </div>

    

	<?php wp_footer(); ?>
  </body>
</html>
