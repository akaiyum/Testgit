<?php get_header(); 

/* Template Name: For About Page
*/
    
if( have_posts() ){
  the_post();
     $page_thumb = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'thumb-img');
     $group_meta_data = get_post_meta(get_the_ID(),'about_group_meta_field', true);
     $content = get_the_content();

     ?>
  <div class="row container-kamn">  
        <img src="<?php echo $page_thumb[0]; ?>" width="100%" class="blog-post" alt="Feature-img" align="right" width="100%"> 

    </div>
<?php
}

?>
<div id="banners"></div>
    <div class="container">   
        <div class="row">
            <div class="side-left col-sm-4 col-md-4">

                 <?php foreach($group_meta_data as  $single){?>
                <h3 class="lead"> <?php echo $single['heading'];?>: </h3><hr>

                <p><?php echo $single['about_description'];?>:</p>
                 <?php foreach($single['hash_link'] as $key => $childSingle ){
                         ?>
                                <a href="<?php echo $childSingle; ?>"> <?php echo $single['hash_link_title'][$key]; ?></a><br>
                         <?php
                 }
                 ?>
                
               
                <br>
                <?php
                     }
                ?>
            </div>
            <div class="col-sm-8 col-md-8">
                <?php 
              
                echo $content;
                
                ?>
            </div>
        </div>
    </div>
                
</div>  

    <!--End Main Container -->

  <?php get_footer(); ?>
