    <?php get_header(); ?>
    <!-- Begin #carousel-section -->
    

<section class="test">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <img src="http://via.placeholder.com/1500x300/f00" alt=""/>
                </div>
            </div>
        </div>
    </section>
    <!-- Begin #services-section -->
   
  
<?php get_footer(); ?>
   