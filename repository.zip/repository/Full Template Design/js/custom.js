$(document).ready(function () {
	$('#navButton').click(function(){
          $('.akaiyum-sidebar-menu').removeClass('sidebar-closed');
	});
	
	$('.btn').click(function(){
          $('.akaiyum-sidebar-menu').addClass('sidebar-closed');
	});

});