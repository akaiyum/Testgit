﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmployeeSalaryApp
{
    public class Salary
    {
        public string EmployeeName { get;  set; }
        public double BasicAmount { get;  set; }
        public double HouseRentPercentage { get;  set; }
        public double MedicalAllowancePercentage { get; set; }

        public Salary(string employeeName,double basicAmount, double houseRentPercentage,double medicalAllowancePercentage)
        {
            EmployeeName = employeeName;
            BasicAmount = basicAmount;
            HouseRentPercentage = houseRentPercentage;
            MedicalAllowancePercentage = medicalAllowancePercentage;
        }



        public double GetHouseRentAmount()
        {
            return (BasicAmount/100)*HouseRentPercentage;
        }

        public double GetMedicalAllowanceAmount()
        {
            return (BasicAmount/100)*MedicalAllowancePercentage;
        }

        public double GetTotalSalary()
        {
            return BasicAmount + GetHouseRentAmount() + GetMedicalAllowanceAmount();
        }
    }
}
