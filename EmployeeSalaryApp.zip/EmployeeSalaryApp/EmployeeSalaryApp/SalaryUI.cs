﻿using System.Windows.Forms;
using System;

namespace EmployeeSalaryApp
{
    public partial class SalaryUI : Form
    {
        public SalaryUI()
        {
            InitializeComponent();
        }

        private void showMeSalaryButton_Click(object sender, System.EventArgs e)
        {
            Salary aSalary = new Salary(employeeNameTextBox.Text,Convert.ToDouble(basicAmountTextBox.Text),Convert.ToDouble(houseRentTextBox.Text),Convert.ToDouble(medicalAllowanceTextBox.Text));
            aSalary.EmployeeName=employeeNameTextBox.Text;
            aSalary.BasicAmount = Convert.ToDouble(basicAmountTextBox.Text);
            aSalary.HouseRentPercentage = Convert.ToDouble(houseRentTextBox.Text);
            aSalary.MedicalAllowancePercentage = Convert.ToDouble(medicalAllowanceTextBox.Text);
            MessageBox.Show(aSalary.EmployeeName + " your total salary is: " + aSalary.GetTotalSalary())
            ;
        }
    }
}
