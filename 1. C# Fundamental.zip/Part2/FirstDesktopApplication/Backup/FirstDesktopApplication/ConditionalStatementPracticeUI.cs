﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace FirstDesktopApplication
{
    public partial class ConditionalStatementPracticeUI : Form
    {
        private enum PlanetNames
        {
            Earth = 3,
            Mars = 4,
            Saturn = 6
        }

        public ConditionalStatementPracticeUI()
        {
            InitializeComponent();
            planetNameComboBox.DataSource = Enum.GetNames(typeof (PlanetNames));
        }

        private void showPlanetNumberButton_Click(object sender, EventArgs e)
        {
            string planetName = planetNameComboBox.Text;
            PlanetNames selectedPlanet = (PlanetNames)Enum.Parse(typeof(PlanetNames), planetNameComboBox.Text);

            switch (selectedPlanet)
            {
                case PlanetNames.Earth:
                    int earth = (int) PlanetNames.Earth;
                    MessageBox.Show(earth.ToString());
                    break;
                case PlanetNames.Mars :
                    int mars = (int) PlanetNames.Mars;
                    MessageBox.Show(mars.ToString());
                    break;
                case PlanetNames.Saturn:
                    int saturn = (int) PlanetNames.Saturn;
                    MessageBox.Show(saturn.ToString());
                    break;
                default:
                    MessageBox.Show("Nothing is selected");
                    break;
            }
        }          
   }
}

