﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PersonalInformation
{
    public partial class PersonalInfoUI : Form
    {
        public PersonalInfoUI()
        {
            InitializeComponent();
        }

        public string firstName;
        public string lastName;
        public string fatherName;
        public string motherName;
        public string address;

        private void saveButton_Click(object sender, EventArgs e)
        {
            firstName = firstNameTextBox.Text;
            lastName = lastNameTextBox.Text;
            fatherName = fatherNameTextBox.Text;
            motherName = motherNameTextBox.Text;
            address = addressTextBox.Text;

            firstNameTextBox.Text = "";
            lastNameTextBox.Text = "";
            fatherNameTextBox.Text = "";
            motherNameTextBox.Text = "";
            addressTextBox.Text = "";

            MessageBox.Show("Save Successfully");

        }

        private void showAllButton_Click(object sender, EventArgs e)
        {

            MessageBox.Show("Name: " + firstName +" "+ lastName + "\nFather Name: " + fatherName + "\nMother Name: " +
                            motherName + "\nAddress : " + address);
         


        }

        private void fullNameButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Full Name: " + firstName +" "+ lastName);
        }

        private void parentsNameButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Parents Name"+"\nFather Name: " + fatherName + "\nMother Name: " +
                            motherName);
        }

        private void addressButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Address : " + address);
         
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void addressTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void firstNameTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void lastNameTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void fatherNameTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void motherNameTextBox_TextChanged(object sender, EventArgs e)
        {

        }

    }
}