﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace InterestCalculationForm
{
    public partial class InterestCalculationUI : Form
    {
        public InterestCalculationUI()
        {
            InitializeComponent();
        }

        public int time;
        public double balance;
        public double interest;
        public double givenInterest;
       
        private void calculateInterestButton_Click(object sender, EventArgs e)
        {
            if(bankNameComboBox.Text=="BRAC")
            {
                givenInterest = 6;   /* interest in percent (6% .. 7% .. 8 %)*/
             

            }
             
            else if(bankNameComboBox.Text=="DBBL")
            {
                givenInterest = 7;
               
            }
            else
            {
                givenInterest = 8;
               
            }
            time = Convert.ToInt32(timeTextBox.Text);
            balance = Convert.ToInt32(balanceTextBox.Text);

            interest = (givenInterest * time * balance)/100;
            interestLabel.Text = Convert.ToString(interest);
            timeTextBox.Text = "";
            balanceTextBox.Text = "";
        }

        private void InterestCalculationUI_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void interestLabel_Click(object sender, EventArgs e)
        {

        }

        private void timeTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void balanceTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void bankNameComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
 

    }
}
