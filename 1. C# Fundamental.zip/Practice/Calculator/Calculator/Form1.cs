﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Calculator
{
    public partial class CalculatorUI : Form
    {
        public CalculatorUI()
        {
            InitializeComponent();
        }

        public double firstNumber;
        public double secondNumber;
        public double result;

        private void addButton_Click(object sender, EventArgs e)
        {
            firstNumber = Convert.ToDouble(firstNumberTextBox.Text);
            secondNumber = Convert.ToDouble(secondNumberTextBox.Text);

            firstNumberTextBox.Text = "";
            secondNumberTextBox.Text = "";

            result = firstNumber + secondNumber;
            resultTextBox.Text = Convert.ToString(result);

           

        }

        private void subButton_Click(object sender, EventArgs e)
        {
            firstNumber = Convert.ToDouble(firstNumberTextBox.Text);
            secondNumber = Convert.ToDouble(secondNumberTextBox.Text);

            firstNumberTextBox.Text = "";
            secondNumberTextBox.Text = "";
            result = firstNumber - secondNumber;
            resultTextBox.Text = Convert.ToString(result);

        }

        private void multiplicationButton_Click(object sender, EventArgs e)
        {
            firstNumber = Convert.ToDouble(firstNumberTextBox.Text);
            secondNumber = Convert.ToDouble(secondNumberTextBox.Text);

            firstNumberTextBox.Text = "";
            secondNumberTextBox.Text = "";
            result = firstNumber * secondNumber;
            resultTextBox.Text = Convert.ToString(result);
        }

        private void divisionButton_Click(object sender, EventArgs e)
        {
            firstNumber = Convert.ToDouble(firstNumberTextBox.Text);
            secondNumber = Convert.ToDouble(secondNumberTextBox.Text);

            firstNumberTextBox.Text = "";
            secondNumberTextBox.Text = "";
            result = firstNumber / secondNumber;
            resultTextBox.Text = Convert.ToString(result);
        }
    }
}
