﻿namespace POS
{
    partial class FrmCalculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnresult = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtsnumber = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtresult = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtfnumber = new System.Windows.Forms.TextBox();
            this.rbadd = new System.Windows.Forms.RadioButton();
            this.rbsub = new System.Windows.Forms.RadioButton();
            this.rbmulti = new System.Windows.Forms.RadioButton();
            this.rbdiv = new System.Windows.Forms.RadioButton();
            this.btn_one = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnresult
            // 
            this.btnresult.Location = new System.Drawing.Point(131, 155);
            this.btnresult.Name = "btnresult";
            this.btnresult.Size = new System.Drawing.Size(75, 23);
            this.btnresult.TabIndex = 0;
            this.btnresult.Text = "Result";
            this.btnresult.UseVisualStyleBackColor = true;
            this.btnresult.Click += new System.EventHandler(this.btnresult_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 75);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Second Number";
            // 
            // txtsnumber
            // 
            this.txtsnumber.Location = new System.Drawing.Point(113, 72);
            this.txtsnumber.Name = "txtsnumber";
            this.txtsnumber.Size = new System.Drawing.Size(153, 20);
            this.txtsnumber.TabIndex = 2;
            this.txtsnumber.MouseClick += new System.Windows.Forms.MouseEventHandler(this.txtsnumber_MouseClick);
            this.txtsnumber.TextChanged += new System.EventHandler(this.txtsnumber_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(37, 114);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Result";
            // 
            // txtresult
            // 
            this.txtresult.Location = new System.Drawing.Point(113, 111);
            this.txtresult.Name = "txtresult";
            this.txtresult.Size = new System.Drawing.Size(153, 20);
            this.txtresult.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(37, 34);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "First Number";
            // 
            // txtfnumber
            // 
            this.txtfnumber.Location = new System.Drawing.Point(113, 31);
            this.txtfnumber.Name = "txtfnumber";
            this.txtfnumber.Size = new System.Drawing.Size(153, 20);
            this.txtfnumber.TabIndex = 2;
            this.txtfnumber.MouseClick += new System.Windows.Forms.MouseEventHandler(this.txtfnumber_MouseClick);
            this.txtfnumber.TextChanged += new System.EventHandler(this.txtfnumber_TextChanged);
            // 
            // rbadd
            // 
            this.rbadd.AutoSize = true;
            this.rbadd.Location = new System.Drawing.Point(327, 31);
            this.rbadd.Name = "rbadd";
            this.rbadd.Size = new System.Drawing.Size(31, 17);
            this.rbadd.TabIndex = 3;
            this.rbadd.TabStop = true;
            this.rbadd.Text = "+";
            this.rbadd.UseVisualStyleBackColor = true;
            // 
            // rbsub
            // 
            this.rbsub.AutoSize = true;
            this.rbsub.Location = new System.Drawing.Point(327, 54);
            this.rbsub.Name = "rbsub";
            this.rbsub.Size = new System.Drawing.Size(28, 17);
            this.rbsub.TabIndex = 4;
            this.rbsub.TabStop = true;
            this.rbsub.Text = "-";
            this.rbsub.UseVisualStyleBackColor = true;
            // 
            // rbmulti
            // 
            this.rbmulti.AutoSize = true;
            this.rbmulti.Location = new System.Drawing.Point(327, 77);
            this.rbmulti.Name = "rbmulti";
            this.rbmulti.Size = new System.Drawing.Size(29, 17);
            this.rbmulti.TabIndex = 4;
            this.rbmulti.TabStop = true;
            this.rbmulti.Text = "*";
            this.rbmulti.UseVisualStyleBackColor = true;
            // 
            // rbdiv
            // 
            this.rbdiv.AutoSize = true;
            this.rbdiv.Location = new System.Drawing.Point(327, 100);
            this.rbdiv.Name = "rbdiv";
            this.rbdiv.Size = new System.Drawing.Size(30, 17);
            this.rbdiv.TabIndex = 4;
            this.rbdiv.TabStop = true;
            this.rbdiv.Text = "/";
            this.rbdiv.UseVisualStyleBackColor = true;
            // 
            // btn_one
            // 
            this.btn_one.Location = new System.Drawing.Point(222, 155);
            this.btn_one.Name = "btn_one";
            this.btn_one.Size = new System.Drawing.Size(44, 23);
            this.btn_one.TabIndex = 5;
            this.btn_one.Text = "1";
            this.btn_one.UseVisualStyleBackColor = true;
            this.btn_one.Click += new System.EventHandler(this.btn_one_Click);
            // 
            // FrmCalculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(534, 214);
            this.Controls.Add(this.btn_one);
            this.Controls.Add(this.rbdiv);
            this.Controls.Add(this.rbmulti);
            this.Controls.Add(this.rbsub);
            this.Controls.Add(this.rbadd);
            this.Controls.Add(this.txtfnumber);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtresult);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtsnumber);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnresult);
            this.Name = "FrmCalculator";
            this.Text = "FrmCalculator";
            this.Load += new System.EventHandler(this.FrmCalculator_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnresult;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtsnumber;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtresult;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtfnumber;
        private System.Windows.Forms.RadioButton rbadd;
        private System.Windows.Forms.RadioButton rbsub;
        private System.Windows.Forms.RadioButton rbmulti;
        private System.Windows.Forms.RadioButton rbdiv;
        private System.Windows.Forms.Button btn_one;
    }
}