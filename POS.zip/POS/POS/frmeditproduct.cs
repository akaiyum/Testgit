﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace POS
{
    public partial class frmeditproduct : Form
    {
        private string connectionString =
             @"server = .\sqlexpress; database = POS; integrated security = true";
        public frmeditproduct()
        {
            InitializeComponent();
        }
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter da;
        DataTable dt;
        public int productId;
        public string name, type, code, company;

        private void dgveditdefineproduct_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            productId = Convert.ToInt32(this.dgveditdefineproduct.CurrentRow.Cells[0].Value);
            name = this.dgveditdefineproduct.CurrentRow.Cells[1].Value.ToString();
            type = this.dgveditdefineproduct.CurrentRow.Cells[2].Value.ToString();
            code = this.dgveditdefineproduct.CurrentRow.Cells[3].Value.ToString();
            company = this.dgveditdefineproduct.CurrentRow.Cells[4].Value.ToString();
            this.Close();
        }

        private void frmeditproduct_Load(object sender, EventArgs e)
        {
            getalldefineproduct();
        }

        private void getalldefineproduct()
        {
            try
            {
                con = new SqlConnection(connectionString);
                con.Open();
                cmd = new SqlCommand("select * from tbl_defineproduct", con);
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                con.Close();
                cmd = null;

                this.dgveditdefineproduct.DataSource = dt;

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }


          

        }
    }
}
