﻿namespace POS
{
    partial class FrmList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtaddtolist = new System.Windows.Forms.TextBox();
            this.lbxfirst = new System.Windows.Forms.ListBox();
            this.lbltextitem = new System.Windows.Forms.Label();
            this.btnaddtolist = new System.Windows.Forms.Button();
            this.lbxsecond = new System.Windows.Forms.ListBox();
            this.btnmoveone = new System.Windows.Forms.Button();
            this.btnmoveall = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lbltotalitem = new System.Windows.Forms.Label();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.removeSelectedItemsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtaddtolist
            // 
            this.txtaddtolist.Location = new System.Drawing.Point(38, 67);
            this.txtaddtolist.Name = "txtaddtolist";
            this.txtaddtolist.Size = new System.Drawing.Size(129, 20);
            this.txtaddtolist.TabIndex = 0;
            // 
            // lbxfirst
            // 
            this.lbxfirst.ContextMenuStrip = this.contextMenuStrip1;
            this.lbxfirst.FormattingEnabled = true;
            this.lbxfirst.Location = new System.Drawing.Point(38, 104);
            this.lbxfirst.Name = "lbxfirst";
            this.lbxfirst.Size = new System.Drawing.Size(129, 95);
            this.lbxfirst.TabIndex = 1;
            this.lbxfirst.DoubleClick += new System.EventHandler(this.lbxfirst_DoubleClick);
            // 
            // lbltextitem
            // 
            this.lbltextitem.AutoSize = true;
            this.lbltextitem.Location = new System.Drawing.Point(35, 40);
            this.lbltextitem.Name = "lbltextitem";
            this.lbltextitem.Size = new System.Drawing.Size(58, 13);
            this.lbltextitem.TabIndex = 2;
            this.lbltextitem.Text = "Item Name";
            // 
            // btnaddtolist
            // 
            this.btnaddtolist.Location = new System.Drawing.Point(38, 220);
            this.btnaddtolist.Name = "btnaddtolist";
            this.btnaddtolist.Size = new System.Drawing.Size(129, 23);
            this.btnaddtolist.TabIndex = 3;
            this.btnaddtolist.Text = "Add To List";
            this.btnaddtolist.UseVisualStyleBackColor = true;
            this.btnaddtolist.Click += new System.EventHandler(this.btnaddtolist_Click);
            // 
            // lbxsecond
            // 
            this.lbxsecond.FormattingEnabled = true;
            this.lbxsecond.Location = new System.Drawing.Point(260, 104);
            this.lbxsecond.Name = "lbxsecond";
            this.lbxsecond.Size = new System.Drawing.Size(129, 95);
            this.lbxsecond.TabIndex = 1;
            this.lbxsecond.DoubleClick += new System.EventHandler(this.lbxfirst_DoubleClick);
            // 
            // btnmoveone
            // 
            this.btnmoveone.Location = new System.Drawing.Point(189, 119);
            this.btnmoveone.Name = "btnmoveone";
            this.btnmoveone.Size = new System.Drawing.Size(46, 23);
            this.btnmoveone.TabIndex = 4;
            this.btnmoveone.Text = ">";
            this.btnmoveone.UseVisualStyleBackColor = true;
            this.btnmoveone.Click += new System.EventHandler(this.btnmoveone_Click);
            // 
            // btnmoveall
            // 
            this.btnmoveall.Location = new System.Drawing.Point(189, 148);
            this.btnmoveall.Name = "btnmoveall";
            this.btnmoveall.Size = new System.Drawing.Size(46, 23);
            this.btnmoveall.TabIndex = 4;
            this.btnmoveall.Text = ">>";
            this.btnmoveall.UseVisualStyleBackColor = true;
            this.btnmoveall.Click += new System.EventHandler(this.btnmoveall_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(257, 74);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(117, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Total number of items =";
            // 
            // lbltotalitem
            // 
            this.lbltotalitem.AutoSize = true;
            this.lbltotalitem.Location = new System.Drawing.Point(371, 74);
            this.lbltotalitem.Name = "lbltotalitem";
            this.lbltotalitem.Size = new System.Drawing.Size(13, 13);
            this.lbltotalitem.TabIndex = 2;
            this.lbltotalitem.Text = "0";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.removeSelectedItemsToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(197, 26);
            // 
            // removeSelectedItemsToolStripMenuItem
            // 
            this.removeSelectedItemsToolStripMenuItem.Name = "removeSelectedItemsToolStripMenuItem";
            this.removeSelectedItemsToolStripMenuItem.Size = new System.Drawing.Size(196, 22);
            this.removeSelectedItemsToolStripMenuItem.Text = "Remove Selected Items";
            this.removeSelectedItemsToolStripMenuItem.Click += new System.EventHandler(this.removeSelectedItemsToolStripMenuItem_Click);
            // 
            // FrmList
            // 
            this.AcceptButton = this.btnaddtolist;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(468, 285);
            this.Controls.Add(this.btnmoveall);
            this.Controls.Add(this.btnmoveone);
            this.Controls.Add(this.btnaddtolist);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbltotalitem);
            this.Controls.Add(this.lbltextitem);
            this.Controls.Add(this.lbxsecond);
            this.Controls.Add(this.lbxfirst);
            this.Controls.Add(this.txtaddtolist);
            this.Name = "FrmList";
            this.Text = "FrmList";
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtaddtolist;
        private System.Windows.Forms.ListBox lbxfirst;
        private System.Windows.Forms.Label lbltextitem;
        private System.Windows.Forms.Button btnaddtolist;
        private System.Windows.Forms.ListBox lbxsecond;
        private System.Windows.Forms.Button btnmoveone;
        private System.Windows.Forms.Button btnmoveall;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbltotalitem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem removeSelectedItemsToolStripMenuItem;
    }
}