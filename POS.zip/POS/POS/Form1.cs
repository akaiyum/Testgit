﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace POS
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Login_Click(object sender, EventArgs e)
        {
           // this line will check wheather the user inputs in id as admin and password as admin
            if(this.txtid.Text=="" && this.txtpass.Text==""){
              // that will show the message to user that successfully loged in
                MessageBox.Show("Loged in");
                this.Hide();
                frmdashboard dash = new frmdashboard();
                dash.WindowState = FormWindowState.Maximized;
                dash.ShowDialog();
                Application.Exit();
                //it will change the back color of text box as white
                this.txtid.BackColor = Color.White;
                //it will change the back color of password text box as white
                this.txtpass.BackColor = Color.White;

            }
                //this line will verify that user id is not equal to admin and password is equal to admin
            
            else if (this.txtid.Text != "admin" && this.txtpass.Text == "admin")
            {
                //it will show that your id is incorrect and password is correct
                MessageBox.Show("Id is incorrect and password is correct");
                //it will clear the user id input
                this.txtid.Clear();
                //it will change the background color as red of user id input
                this.txtid.BackColor = Color.Red;
                //control will goes to user input
                this.txtid.Focus();
            }
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you want to exit the post??","Exit",MessageBoxButtons.YesNo,MessageBoxIcon.Question);
            if(result==DialogResult.Yes){
            Application.Exit();
            }
        }

        
    }
}
