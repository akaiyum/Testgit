﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace POS
{
    public partial class FrmList : Form
    {
        public FrmList()
        {
            InitializeComponent();
        }

        private void btnaddtolist_Click(object sender, EventArgs e)
        {
            if (this.txtaddtolist.Text.Trim() != "")
            {
                this.lbxfirst.Items.Add(this.txtaddtolist.Text);
                this.txtaddtolist.Clear();
                this.txtaddtolist.Focus();

            }
            else {
                MessageBox.Show("Please Write an item in the text field");
            
            }
        }

        private void lbxfirst_DoubleClick(object sender, EventArgs e)
        {
            if (this.lbxfirst.Items.Count > 0)
            {
                if (this.lbxfirst.SelectedIndex > -1)
                {
                    MessageBox.Show("You select an item which is " + this.lbxfirst.SelectedItem);
                }
                else {
                    MessageBox.Show("Please select an item from list box to show");
                
                }
            }
            else {
                MessageBox.Show("List box is empty");
            }

            
        }

        private void btnmoveone_Click(object sender, EventArgs e)
        {
            if (this.lbxfirst.Items.Count > 0)
            {
                if (this.lbxfirst.SelectedIndex > -1)
                {
                    this.lbxsecond.Items.Add(this.lbxfirst.SelectedItem);
                    this.lbxfirst.Items.RemoveAt(this.lbxfirst.SelectedIndex);
                    this.lbltotalitem.Text = this.lbxsecond.Items.Count.ToString();
                }
                else
                {
                    MessageBox.Show("Please select an item from list box to Move");

                }
            }
            else
            {
                MessageBox.Show("List box is empty");
            }

        }

        private void btnmoveall_Click(object sender, EventArgs e)
        {
            if (this.lbxfirst.Items.Count > 0)
            {
                for (int i = 0; i < lbxfirst.Items.Count; i++ )
                {
                    this.lbxsecond.Items.Add(this.lbxfirst.Items[i]);

                }
                this.lbxfirst.Items.Clear();
                this.lbltotalitem.Text = this.lbxsecond.Items.Count.ToString();
            }
            else
            {
                MessageBox.Show("List box is empty");
            }
        }

        private void removeSelectedItemsToolStripMenuItem_Click(object sender, EventArgs e)
        {

            if (this.lbxfirst.Items.Count > 0)
            {
                if (this.lbxfirst.SelectedIndex > -1)
                {
                    DialogResult result = MessageBox.Show("Are you want to remove an item from list???","Remove",MessageBoxButtons.YesNo,MessageBoxIcon.Stop);
                    this.lbxfirst.Items.RemoveAt(this.lbxfirst.SelectedIndex);
                }
                else
                {
                    MessageBox.Show("Please select an item from list box to show");

                }
            }
            else
            {
                MessageBox.Show("List box is empty");
            }

        }
    }
}
