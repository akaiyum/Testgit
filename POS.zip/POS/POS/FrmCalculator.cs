﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace POS
{
    public partial class FrmCalculator : Form
    {
        string focus = " ";
        public FrmCalculator()
        {
            InitializeComponent();
        }

        private void FrmCalculator_Load(object sender, EventArgs e)
        {

        }

        private void btnresult_Click(object sender, EventArgs e)
        {
            //int fnum, snum, result;
            //fnum = Convert.ToInt32(this.txtfnumber.Text);
            //snum = Convert.ToInt32(this.txtsnumber.Text);

            //result = fnum + snum;
            //this.txtresult.Text = result.ToString();

            if (rbadd.Checked)
            {
                if (this.txtfnumber.Text.Trim() != "" && this.txtsnumber.Text.Trim() != "")
                {

                    this.txtresult.Text = (Convert.ToInt32(this.txtfnumber.Text) + Convert.ToInt32(this.txtsnumber.Text)).ToString();
                }
                else
                {
                    this.txtresult.Text = "";

                }

            }
            else if (rbsub.Checked)
            {
                if (this.txtfnumber.Text.Trim() != "" && this.txtsnumber.Text.Trim() != "")
                {

                    this.txtresult.Text = (Convert.ToInt32(this.txtfnumber.Text) - Convert.ToInt32(this.txtsnumber.Text)).ToString();
                }
                else
                {
                    this.txtresult.Text = "";

                }

            }
            else if (rbmulti.Checked)
            {
                if (this.txtfnumber.Text.Trim() != "" && this.txtsnumber.Text.Trim() != "")
                {

                    this.txtresult.Text = (Convert.ToInt32(this.txtfnumber.Text) * Convert.ToInt32(this.txtsnumber.Text)).ToString();
                }
                else
                {
                    this.txtresult.Text = "";

                }

            }
            else if (rbdiv.Checked)
            {
                if (this.txtfnumber.Text.Trim() != "" && this.txtsnumber.Text.Trim() != "")
                {

                    this.txtresult.Text = (Convert.ToInt32(this.txtfnumber.Text) / Convert.ToInt32(this.txtsnumber.Text)).ToString();
                }
                else
                {
                    this.txtresult.Text = "";

                }

            }
            else
            {
                MessageBox.Show("Please select an operation from radio button");
            }
        }

        private void txtsnumber_TextChanged(object sender, EventArgs e)
        {
            if (rbadd.Checked)
            {
                if (this.txtfnumber.Text.Trim() != "" && this.txtsnumber.Text.Trim() != "")
                {

                    this.txtresult.Text = (Convert.ToInt32(this.txtfnumber.Text) + Convert.ToInt32(this.txtsnumber.Text)).ToString();
                }
                else
                {
                    this.txtresult.Text = "";

                }

            }
            else if (rbsub.Checked)
            {
                if (this.txtfnumber.Text.Trim() != "" && this.txtsnumber.Text.Trim() != "")
                {

                    this.txtresult.Text = (Convert.ToInt32(this.txtfnumber.Text) - Convert.ToInt32(this.txtsnumber.Text)).ToString();
                }
                else
                {
                    this.txtresult.Text = "";

                }

            }
            else if (rbmulti.Checked)
            {
                if (this.txtfnumber.Text.Trim() != "" && this.txtsnumber.Text.Trim() != "")
                {

                    this.txtresult.Text = (Convert.ToInt32(this.txtfnumber.Text) * Convert.ToInt32(this.txtsnumber.Text)).ToString();
                }
                else
                {
                    this.txtresult.Text = "";

                }

            }
            else if (rbdiv.Checked)
            {
                if (this.txtfnumber.Text.Trim() != "" && this.txtsnumber.Text.Trim() != "")
                {

                    this.txtresult.Text = (Convert.ToInt32(this.txtfnumber.Text) / Convert.ToInt32(this.txtsnumber.Text)).ToString();
                }
                else
                {
                    this.txtresult.Text = "";

                }

            }
            else
            {
                MessageBox.Show("Please select an operation from radio button");
            }

        }

        private void txtfnumber_TextChanged(object sender, EventArgs e)
        {
            if(rbadd.Checked){
                if (this.txtfnumber.Text.Trim() != "" && this.txtsnumber.Text.Trim() != "")
                {

                    this.txtresult.Text = (Convert.ToInt32(this.txtfnumber.Text) + Convert.ToInt32(this.txtsnumber.Text)).ToString();
                }
                else
                {
                    this.txtresult.Text = "";

                }
            
            }else if(rbsub.Checked){
                if (this.txtfnumber.Text.Trim() != "" && this.txtsnumber.Text.Trim() != "")
                {

                    this.txtresult.Text = (Convert.ToInt32(this.txtfnumber.Text) - Convert.ToInt32(this.txtsnumber.Text)).ToString();
                }
                else
                {
                    this.txtresult.Text = "";

                }
            
            }else if(rbmulti.Checked){
                if (this.txtfnumber.Text.Trim() != "" && this.txtsnumber.Text.Trim() != "")
                {

                    this.txtresult.Text = (Convert.ToInt32(this.txtfnumber.Text) * Convert.ToInt32(this.txtsnumber.Text)).ToString();
                }
                else
                {
                    this.txtresult.Text = "";

                }

            }
            else if (rbdiv.Checked)
            {
                if (this.txtfnumber.Text.Trim() != "" && this.txtsnumber.Text.Trim() != "")
                {

                    this.txtresult.Text = (Convert.ToInt32(this.txtfnumber.Text) / Convert.ToInt32(this.txtsnumber.Text)).ToString();
                }
                else
                {
                    this.txtresult.Text = "";

                }

            }
            else {
                MessageBox.Show("Please select an operation from radio button");
            }




            
        }

        private void btn_one_Click(object sender, EventArgs e)
        {
            if(focus=="first"){
                this.txtfnumber.Text += "1";
            }
            if(focus=="second"){
                this.txtsnumber.Text += "1";
            }

            
        }

        private void txtsnumber_MouseClick(object sender, MouseEventArgs e)
        {
            focus = "second";
            this.txtsnumber.Focus();
        }

        private void txtfnumber_MouseClick(object sender, MouseEventArgs e)
        {
            focus = "first";
            this.txtfnumber.Focus();
        }
    }
}
