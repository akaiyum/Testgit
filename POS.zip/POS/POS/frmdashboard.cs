﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace POS
{
    public partial class frmdashboard : Form
    {
        public frmdashboard()
        {
            InitializeComponent();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void sampleCalculatorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmCalculator cal = new FrmCalculator();
            cal.Show();
        }

        private void listToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmList frm = new FrmList();
            frm.ShowDialog();
        }

        private void defineCompanyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmdefinecompany fcompany = new frmdefinecompany();
            fcompany.StartPosition = FormStartPosition.CenterScreen;
            fcompany.Show();
        }

        private void defineProductToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmdefineproduct fpro = new frmdefineproduct();
            fpro.Show();
        }

        private void purchaseProductToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmpurchaseproduct fpurchase = new frmpurchaseproduct();
            fpurchase.Show();
        }
    }
}
