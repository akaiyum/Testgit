﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace POS
{
    public partial class frmedicompany : Form
    {
        public frmedicompany()
        {
            InitializeComponent();
        }

        private void frmedicompany_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'pOSDataSet.tbl_company' table. You can move, or remove it, as needed.
            this.tbl_companyTableAdapter.Fill(this.pOSDataSet.tbl_company);

        }
    }
}
