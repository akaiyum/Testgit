﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace POS
{
    public partial class frmdefinecompany : Form
    {

        private string connectionString =
               @"server = .\sqlexpress; database = POS; integrated security = true";
        public frmdefinecompany()
        {
            InitializeComponent();
        }

        private void frmdefinecompany_Load(object sender, EventArgs e)
        {
            getnextcompanyid();
            clearcontrols();
        }

        private void clearcontrols()
        {
            this.txtcompanyname.Clear();
            this.txtcomcontactnum.Clear();
            this.txtcomaddress.Clear();
            this.txtcompanyname.Focus();
        }

        private void getnextcompanyid()
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlCommand com = new SqlCommand();
            com.Connection = con;
            com.CommandText = "select ISNULL(max(companyid),0)+1 from tbl_company";
            this.txtcompanyid.Text = com.ExecuteScalar().ToString();
            con.Close();
            com = null;
        }

        

        private void btnsave_Click(object sender, EventArgs e)
        {

            
           

            if (this.txtcompanyid.Text.Trim() != "" && this.txtcompanyname.Text.Trim() != "" && this.txtcomcontactnum.Text.Trim() != "" && this.txtcomaddress.Text.Trim() != "")
            {
                SqlConnection con = new SqlConnection(connectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = "select companyname from tbl_company where companyname='"+this.txtcompanyname.Text+"'";
                object obj = cmd.ExecuteScalar();
                if(obj==null){
                    cmd.CommandText = "insert into tbl_company values(" + this.txtcompanyid.Text + ",'" + this.txtcompanyname.Text + "','" + this.txtcomcontactnum.Text + "','" + this.txtcomaddress.Text + "')";
                    cmd.CommandType = CommandType.Text;
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Company Defined");
                    con.Close();
                    cmd = null;
                    getnextcompanyid();
                    clearcontrols();
                }else{
                        MessageBox.Show("Company already registered");
                }
                
            }
            else
            {
                MessageBox.Show("Please Enter required field");

            }

        }

        private void btnclose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandText = "select COUNT(*) from tbl_company where companyid="+this.txtcompanyid.Text;
            int count = Convert.ToInt32(cmd.ExecuteScalar());
            if (count != 0)
            {
                cmd.CommandText = "update tbl_company set companyname='" + this.txtcompanyname.Text + "', companycontactnum='" + this.txtcomcontactnum.Text + "', companyaddress='" + this.txtcomaddress.Text + "' where companyid=" + this.txtcompanyid.Text;
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                MessageBox.Show("Company updated");
                con.Close();
                cmd = null;
                getnextcompanyid();
                clearcontrols();
            }
            else {
                MessageBox.Show("record does not updated behind this id updated, please save first");
            }
            

        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandText = "select COUNT(*) from tbl_company where companyid=" + this.txtcompanyid.Text;
            int count = Convert.ToInt32(cmd.ExecuteScalar());
            if (count != 0)
            {
                cmd.CommandText = "delete from tbl_company where companyid=" + this.txtcompanyid.Text;
                cmd.ExecuteScalar();
                con.Close();
                cmd = null;
                MessageBox.Show("Company Deleted");
                getnextcompanyid();
                clearcontrols();

            }
            else {
                MessageBox.Show("record does not deleted behind this id, please save first");
            }
            
        }

        private void btnrefresh_Click(object sender, EventArgs e)
        {
            getnextcompanyid();
            clearcontrols();
        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            frmedicompany edi = new frmedicompany();
            edi.Show();
        }

        

       
    }
}
