﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;


namespace POS
{
    public partial class frmdefineproduct : Form
    {
        private string connectionString =
               @"server = .\sqlexpress; database = POS; integrated security = true";
        public frmdefineproduct()
        {
            InitializeComponent();
        }
        SqlCommand cmd;
        SqlConnection con;
        SqlDataAdapter da;
        DataTable dt;
        int productId = 0;

        private void frmdefineproduct_Load(object sender, EventArgs e)
        {
            getallcompanyies();

        }

        private void getallcompanyies()
        {
            con = new SqlConnection(connectionString);
            con.Open();
            cmd = new SqlCommand("select * from tbl_company", con);
            da = new SqlDataAdapter(cmd);
            dt = new DataTable();
            da.Fill(dt);
            con.Close();
            cmd = null;
            this.cbxcompany.DataSource = dt;
            this.cbxcompany.DisplayMember = "companyname";
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            con = new SqlConnection(connectionString);
            con.Open();
            cmd = new SqlCommand();
            cmd.Connection = con;

            int getnextproductid = getproductid();

            cmd.CommandText = "insert into tbl_defineproduct values("+getnextproductid+",'"+this.txtproname.Text+"','"+this.txtpro.Text+"','"+this.txtprocod.Text+"','"+this.cbxcompany.Text+"')";
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();
            con.Close();
            cmd = null;
            MessageBox.Show("Product define");

        }

        private int getproductid()
        {
            con = new SqlConnection(connectionString);
            con.Open();
            cmd = new SqlCommand("select ISNULL(MAX(productid),0)+1 from tbl_defineproduct", con);
            return Convert.ToInt32(cmd.ExecuteScalar());

            
        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            frmeditproduct editpro = new frmeditproduct();
            editpro.StartPosition = FormStartPosition.CenterScreen;
            editpro.Show();
            if(editpro.productId!=0){
                this.txtproname.Text = editpro.name;
                this.txtpro.Text = editpro.type;
                this.txtprocod.Text = editpro.code;
                this.cbxcompany.Text = editpro.company;

            }
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (productId!=0)
                {
                    con = new SqlConnection(connectionString);
                    con.Open();
                    cmd = new SqlCommand("select * from tbl_defineproduct where productid=" + productId + "", con);
                    cmd.ExecuteScalar();
                    con.Close();
                    cmd = null;
                    clearcontrol();
                }
               

            }
            catch (Exception)
            {
                
                throw;
            }
        }
        private void clearcontrol() {
            this.txtproname.Clear();
            this.txtpro.Clear();
            this.txtprocod.Clear();
            this.cbxcompany.SelectedIndex = 0;
            productId = 0;
        
        }
        
    }
}
