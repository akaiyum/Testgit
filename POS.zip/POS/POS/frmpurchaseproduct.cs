﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace POS
{
    public partial class frmpurchaseproduct : Form
    {
        private string connectionString =
               @"server = .\sqlexpress; database = POS; integrated security = true";
        public frmpurchaseproduct()
        {
            InitializeComponent();
        }
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter da;
        DataTable dtproduct;

        private void frmpurchaseproduct_Load(object sender, EventArgs e)
        {
            getallcompanies();

        }

        private void getallcompanies()
        {
            try
            {
                con = new SqlConnection(connectionString);
                con.Open();
                cmd = new SqlCommand("select companyname from tbl_company", con);
                da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                this.cbxprocompany.DataSource = dt;
                this.cbxprocompany.DisplayMember = "companyname";
                con.Close();
                cmd = null;

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void cbxprocompany_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                con = new SqlConnection(connectionString);
                con.Open();
                cmd = new SqlCommand("select * from tbl_defineproduct where company='"+this.cbxprocompany.Text+"'", con);
                da = new SqlDataAdapter(cmd);
                 dtproduct = new DataTable();
                 da.Fill(dtproduct);
                 if (dtproduct != null)
                 {
                     if (dtproduct.Rows.Count > 0)
                     {

                         this.cbxprocode.DataSource = dtproduct;
                         this.cbxprocode.DisplayMember = "productcode";
                     }
                     else {
                         this.txtprotype.Clear();
                         this.txtproname.Clear();
                         this.cbxprocode.Text = " ";
                     
                     }
                     
                 }
                 else {

                     this.txtprotype.Clear();
                     this.txtproname.Clear();
                     this.cbxprocode.SelectedIndex = -1;

                 }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void cbxprocode_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.txtproname.Text = dtproduct.Rows[this.cbxprocode.SelectedIndex]["productname"].ToString();
            this.txtprotype.Text = dtproduct.Rows[this.cbxprocode.SelectedIndex]["producttype"].ToString();
        }

        private void txtproprice_TextChanged(object sender, EventArgs e)
        {
            if (this.txtproprice.Text != "" && this.txtquantity.Text != "")
            {
                this.txttotal.Text = (Convert.ToInt32(this.txtquantity.Text) * Convert.ToDouble(this.txtproprice.Text)).ToString();
            }
            else {

                this.txttotal.Clear();

            }
        }

        private void txtquantity_TextChanged(object sender, EventArgs e)
        {
            if (this.txtproprice.Text != "" && this.txtquantity.Text != "")
            {
                this.txttotal.Text = (Convert.ToInt32(this.txtquantity.Text) * Convert.ToDouble(this.txtproprice.Text)).ToString();
            }
            else
            {

                this.txttotal.Clear();

            }
        }
        int sno = 0;
        double total = 0;
        private void btnaddtocard_Click(object sender, EventArgs e)
        {
            sno++;
            object[] add_data_to_gridview = { sno, this.txtproname.Text, this.txtprotype.Text, this.cbxprocode.Text, this.cbxprocompany.Text, dtpurchase.Value.ToShortDateString(), this.txtproprice.Text, this.txtquantity.Text, this.txttotal.Text };
            this.dgvpurchas.Rows.Add(add_data_to_gridview);
            for (int i = 0; i < this.dgvpurchas.Rows.Count - 1; i++ )
            {
                total += Convert.ToDouble(this.dgvpurchas.Rows[i].Cells[8].Value);

            }
            this.txtpurchasetotal.Text = total.ToString();
            this.txtgrandtotal.Text = this.txtpurchasetotal.Text;
            total = 0;

        }

        private void txtdiscount_TextChanged(object sender, EventArgs e)
        {
            if(this.txtpurchasetotal.Text !="" && this.txtgrandtotal.Text!="" && this.txtdiscount.Text!=""){
             this.txtgrandtotal.Text = (Convert.ToDouble(this.txtpurchasetotal.Text)-Convert.ToDouble(this.txtdiscount.Text)).ToString();
            }
            else if (this.txtpurchasetotal.Text != "" && this.txtgrandtotal.Text != "" && this.txtdiscount.Text == "")
            {
                this.txtgrandtotal.Text = this.txtpurchasetotal.Text;
            }
            else {
                this.txtdiscount.Text = "";
            }
        }

        

        

        
    }
}
