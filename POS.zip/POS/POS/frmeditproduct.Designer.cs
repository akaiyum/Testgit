﻿namespace POS
{
    partial class frmeditproduct
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgveditdefineproduct = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgveditdefineproduct)).BeginInit();
            this.SuspendLayout();
            // 
            // dgveditdefineproduct
            // 
            this.dgveditdefineproduct.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgveditdefineproduct.Location = new System.Drawing.Point(0, 109);
            this.dgveditdefineproduct.Name = "dgveditdefineproduct";
            this.dgveditdefineproduct.Size = new System.Drawing.Size(587, 150);
            this.dgveditdefineproduct.TabIndex = 0;
            this.dgveditdefineproduct.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgveditdefineproduct_CellDoubleClick);
            // 
            // frmeditproduct
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(589, 262);
            this.Controls.Add(this.dgveditdefineproduct);
            this.Name = "frmeditproduct";
            this.Text = "frmeditproduct";
            this.Load += new System.EventHandler(this.frmeditproduct_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgveditdefineproduct)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgveditdefineproduct;
    }
}