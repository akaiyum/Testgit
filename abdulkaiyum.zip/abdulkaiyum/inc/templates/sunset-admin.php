<h1>Akaiyum Theme Options</h1>
<h3 class="title">Manage Options</h3>
<p>Customize the default wordpress appearance options</p>
<?php settings_errors(); 
$picture = esc_attr( get_option( 'profile_picture' ) );
$firstName = esc_attr(get_option('first_name'));
$lastName = esc_attr(get_option('last_name'));
$fullName = $firstName.' '.$lastName;
$userDescription = esc_attr(get_option('user_description'));


?>

<div class="sunset-sidebar-preview">
	<div class="sunset-sidebar">
		<div class="image-container">
			<div id="profile-picture-preview" class="profile-picture" style="background-image: url(<?php print $picture; ?>);"></div>
		</div>
		<h2 class="sunset-username"><?php print $fullName; ?></h2>
		<h2 class="sunset-description"><?php print $userDescription; ?></h2>
	</div>
	<div class="icon-wrapper">
		
	</div>
</div>
<form method="post" action="options.php" class="sunset-general-form">
	<?php settings_fields('sunset-setting-group'); ?>
	<?php do_settings_sections('abdul_kaiyum'); ?>
	<?php submit_button('Save Changes', 'primary', 'btnSubmit'); ?>
</form> 