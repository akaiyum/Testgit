<h1>Akaiyum Theme support</h1>

<?php

settings_errors(); 

?>
<form method="post" action="options.php" class="sunset-general-form">
	<?php settings_fields('sunset-theme-support'); ?>
	<?php do_settings_sections('akaiyum_theme_support'); ?>
	<?php submit_button(); ?>
</form> 