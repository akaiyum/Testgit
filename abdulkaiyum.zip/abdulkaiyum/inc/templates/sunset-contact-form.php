<h1>Akaiyum contact forom</h1>
<?php settings_errors(); ?>

<form method="post" action="options.php" class="sunset-general-form">
	<?php settings_fields('sunset-contact-option'); ?>
	<?php do_settings_sections('akaiyum_theme_contact'); ?>
	<?php submit_button('Save Changes', 'primary', 'btnSubmit'); ?>
</form> 