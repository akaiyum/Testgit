<?php

function sunset_add_admin_page(){
     add_menu_page('Sunset Theme Option', 'Sunset Theme Option', 'manage_options', 'abdul_kaiyum', 'sunset_theme_create_page', get_template_directory_uri().'/img/sunset-icon.png', 110);

     //Generate Akaiyum admin submenu page

     add_submenu_page('abdul_kaiyum', 'Akaiyum Setting', 'General', 'manage_options', 'abdul_kaiyum', 'sunset_theme_setting_page');
     add_submenu_page('abdul_kaiyum', 'Akaiyum Theme Option', 'Theme Option', 'manage_options', 'akaiyum_theme_support', 'sunset_theme_support_page');
     add_submenu_page('abdul_kaiyum', 'Akaiyum Contact Form', 'Contact Form', 'manage_options', 'akaiyum_theme_contact', 'sunset_theme_contact_page');
     add_submenu_page('abdul_kaiyum', 'Akaiyum Custom Css', 'Custom Css Option', 'manage_options', 'akaiyum_theme_custom_css', 'sunset_theme_css_section');
    
         // Activate custom setting
add_action('admin_init', 'sunset_custom_settings');
}
add_action('admin_menu', 'sunset_add_admin_page');
function sunset_custom_settings(){
	register_setting('sunset-setting-group', 'first_name');
	register_setting('sunset-setting-group', 'last_name');
	register_setting('sunset-setting-group', 'twitter_handler', 'sunset_sanitize_twitter_handler');
	register_setting('sunset-setting-group', 'facebook_handler');
	register_setting('sunset-setting-group', 'gplus_handler');
	register_setting('sunset-setting-group', 'user_description');
	register_setting('sunset-setting-group', 'profile_picture');

	register_setting('sunset-theme-support', 'post_formats', 'sunset_post_formats_callback');
	register_setting('sunset-theme-support', 'custom_header');
	register_setting('sunset-theme-support', 'custom_background');
	register_setting('sunset-theme-support', 'custom_background');


	register_setting('sunset-contact-option', 'activate_contact');

	register_setting('sunset-custom-css-option', 'active_css', 'sunset_sanitize_custom_css');

	add_settings_section('sunset-sidebar-options', 'Sidebar Options', 'sunset_sidebar_options', 'abdul_kaiyum');

	add_settings_section('sunset-theme-option', 'Theme Options', 'sunset_theme_options', 'akaiyum_theme_support');

	add_settings_section('sunset-contact-section', 'Contact Form', 'sunset_theme_contact_section', 'akaiyum_theme_contact');

	add_settings_section('sunset-custom-css-section', 'Custom Css', 'sunset_theme_custom_css_section', 'akaiyum_theme_custom_css');

    add_settings_field('sidebar-profile-picture', 'Profile Picture', 'sunset_sidebar_picture', 'abdul_kaiyum', 'sunset-sidebar-options');
	add_settings_field('sidebar-name', 'Full Name', 'sunset_sidebar_name', 'abdul_kaiyum', 'sunset-sidebar-options');
	add_settings_field('sidebar-twitter', 'Twitter Handler', 'sunset_sidebar_twitter', 'abdul_kaiyum', 'sunset-sidebar-options');
	add_settings_field('sidebar-facebook', 'Facebook Handler', 'sunset_sidebar_facebook', 'abdul_kaiyum', 'sunset-sidebar-options');
	add_settings_field('sidebar-gplus', 'gplus handler', 'sunset_sidebar_gplus', 'abdul_kaiyum', 'sunset-sidebar-options');
	add_settings_field('sidebar-description', 'User Description', 'sunset_sidebar_description', 'abdul_kaiyum', 'sunset-sidebar-options');

	add_settings_field('post-formats', 'Post Formats', 'sunset_post_formats', 'akaiyum_theme_support', 'sunset-theme-option');
	add_settings_field('custom-header', 'Custom Header', 'sunset_custom_header', 'akaiyum_theme_support', 'sunset-theme-option');
	add_settings_field('custom-background', 'Custom footer', 'sunset_custom_background', 'akaiyum_theme_support', 'sunset-theme-option');

	add_settings_field('activate-form', 'Activate Contact Form', 'sunset_activate_contact', 'akaiyum_theme_contact', 'sunset-contact-section');
	add_settings_field('custom-css', 'Inserted your computer css', 'sunset_activate_custom_css', 'akaiyum_theme_custom_css', 'sunset-custom-css-section');
	
	
}
function sunset_activate_contact(){
	$activate = get_option('activate_contact');
	$checked = (@$activate ==1 ? 'checked':'');
	echo '<lable><input type="checkbox" id="contact_form" name="activate_contact" value="1" '.$checked.'/></lable>';
}
function sunset_custom_header(){
	$options = get_option('custom_header');
	$checked = ( @$options[$format] == 1 ? 'checked' : '' );
	echo '<label><input type="checkbox" id="custom_header" name="custom_header" value="1" '.$checked.' />Active the custom header</label><br>';
}
function sunset_custom_background(){
	$options = get_option('custom_background');
	$checked = ( @$options[$format] == 1 ? 'checked' : '' );
	echo '<label><input type="checkbox" id="custom_background" name="custom_background" value="1" '.$checked.' />Active the custom background</label><br>';
}
function sunset_post_formats_callback( $input ){
    return $input;
}
function sunset_theme_custom_css_section(){
	echo 'Customize sunset theme with your own css';
}
function sunset_theme_options(){
	echo 'Activate and Deactivate our theme support option';
}
function sunset_sidebar_options(){
	// generation of our admin page
}
function sunset_theme_contact_section(){
	echo 'Activate the contact section';
}
function sunset_activate_custom_css(){
    $css = get_option( 'active_css' );
    $css = (empty($css) ? '/*Akaiyum theme custom css*/' : $css);
    echo '<div id="customCss">'.$css.' </div><textarea id="sunset_css" name="sunset_css" style="display:none; visible:hidden;">'.$css.'</textarea>';
}
function sunset_theme_css_section(){
	require_once(get_template_directory().'/inc/templates/sunset-custom-css.php');
}

function sunset_theme_support_page(){
	require_once(get_template_directory().'/inc/templates/sunset-theme-support.php');
}
function sunset_theme_contact_page(){
	require_once(get_template_directory().'/inc/templates/sunset-contact-form.php');
}
function sunset_post_formats(){
	$options = get_option( 'post_formats' );
	$formats = array( 'aside', 'gallery', 'link', 'image', 'quote', 'status', 'video', 'audio', 'chat' );
	$output = '';
	foreach ( $formats as $format ){
		$checked = ( @$options[$format] == 1 ? 'checked' : '' );
		$output .= '<label><input type="checkbox" id="'.$format.'" name="post_formats['.$format.']" value="1" '.$checked.' /> '.$format.'</label><br>';
	}
	echo $output;

}
function sunset_sidebar_picture(){
	$picture = esc_attr(get_option('profile_picture'));
	if (empty($picture)) {
		echo '<input type="button" class="button button-secondary" id="upload-button" value="Upload your profile picture"><input type="hidden" name="profile_picture" value="" id="profile-picture">';
	}else{
    echo '<input type="button" class="button button-secondary" id="upload-button" value="Replace your profile picture"><input type="hidden" name="profile_picture" value="'.$picture.'" id="profile-picture"> <input type="button" class="button button-secondary" value="Remove Picture" id="remove-picture">';
}
}
function sunset_sidebar_name(){
	$firstName = esc_attr(get_option('first_name'));
	$lastName = esc_attr(get_option('last_name'));
	echo '<input type="text" name="first_name" value="'.$firstName.'" placeholder="First Name"> <input type="text" name="last_name" value="'.$lastName.'" placeholder="Last Name">';
}
function sunset_sidebar_twitter(){
	$twitterHandler = esc_attr(get_option('twitter_handler'));
	echo '<input type="text" name="twitter_handler" value="'.$twitterHandler.'" placeholder="Twitter Handler"><p class="description">input your twitter username without the @ character</p>';
}
function sunset_sidebar_facebook(){
	$facebookHandler = esc_attr(get_option('facebook_handler'));
	echo '<input type="text" name="facebook_handler" value="'.$facebookHandler.'" placeholder="Facebook Handler">';
}
function sunset_sidebar_gplus(){
	$gplusHandler = esc_attr(get_option('gplus_handler'));
	echo '<input type="text" name="gplus_handler" value="'.$gplusHandler.'" placeholder="Gplus Handler">';
}
function sunset_sidebar_description(){
	$userDescription = esc_attr(get_option('user_description'));
	echo '<input type="text" name="user_description" value="'.$userDescription.'" placeholder="User Description"><p class="description">Write somthing smart</p>';
}


function sunset_theme_setting_page(){
	// generation of our admin page
} 

function sunset_theme_create_page(){
	require_once(get_template_directory().'/inc/templates/sunset-admin.php');
}
function sunset_theme_setting_css_option(){
	echo "<h1>Sunset css options<h1>";
}


//Sanitization setting
function sunset_sanitize_twitter_handler($input){
   $output = sanitize_text_field($input);
   $output = str_replace('@', '', $output);
   return $output;
}
function sunset_sanitize_custom_css(){
	$output = esc_textarea($input);
   return $output;
}
