<?php
wp_footer();
?>
<div class="sunset-footer text-center">developed by md abdul kaiyum</div>
</body>

</html>