﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace WindowsFormsApplication6
{
    class view_class
    {
        private string connectionString =
               @"server = .\sqlexpress; database = OOPDB40; integrated security = true";
        string querry;

        public view_class(string q)
        {
            this.querry = q;
        }


        public DataTable showrecord() 
        {
            DataTable dt = new DataTable();
            SqlConnection conn = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand(querry, conn);
            try
            {
                conn.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt.Load(dr);

                }
                else {
                    MessageBox.Show("No Record Found");
                }
            }
            catch (Exception)
            {
                MessageBox.Show("No Record were found");

            }
            finally
            {
            conn.Close();
            
                    }
            return dt;

            }
        

    }
}
