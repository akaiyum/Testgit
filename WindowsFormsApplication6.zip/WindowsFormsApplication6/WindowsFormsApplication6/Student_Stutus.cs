﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsFormsApplication6
{
    class Student_Stutus:Classes
    {
        public int status_id { get; set; }
        public int status_student_id { get; set; }
        public string year { get; set; }
    }
}
