﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsFormsApplication6
{
    class Student_Image:Student
    {
        public int img_id { get; set; }
        public string img_path { get; set; }
    }
}
