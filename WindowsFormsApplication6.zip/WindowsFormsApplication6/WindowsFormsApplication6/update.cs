﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace WindowsFormsApplication6
{
    class update
    {
        private string connectionString =
               @"server = .\sqlexpress; database = OOPDB40; integrated security = true";
        public string update_srecord(Student s)
        {
            string msg = " ";
            SqlConnection conn = new SqlConnection(connectionString);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("update_student", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@std_id", SqlDbType.Int, 20).Value = s.s_id;
                cmd.Parameters.Add("@std_name", SqlDbType.NVarChar, 20).Value = s.sname;
                cmd.Parameters.Add("@std_fname", SqlDbType.NVarChar, 20).Value = s.sfname;
                cmd.Parameters.Add("@std_gender", SqlDbType.NVarChar, 6).Value = s.sgender;
                cmd.Parameters.Add("@std_address", SqlDbType.NVarChar, 100).Value = s.saddress;
                cmd.Parameters.Add("@std_admissiondate", SqlDbType.NVarChar, 20).Value = s.sdate;
                cmd.Parameters.Add("@std_ad_fk_id", SqlDbType.NVarChar, 20).Value = s.sfk;
                


                cmd.ExecuteNonQuery();
                msg = "Data Successfully Updated!";
            }
            catch (Exception)
            {
                msg = "Data is not Successfully Updated!";
                throw;

            }
            finally
            {
                conn.Close();
            }
            return msg;
        }
    }
}
