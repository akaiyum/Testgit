﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;


namespace WindowsFormsApplication6
{
    public partial class UpdateForm : Form
    {
        private string connectionString =
               @"server = .\sqlexpress; database = OOPDB40; integrated security = true";


        public UpdateForm()
        {
            InitializeComponent();
        }

        private void UpdateForm_Load(object sender, EventArgs e)
        {

        }

        private void textBox3_KeyUp(object sender, KeyEventArgs e)
        {
            textBox1.Text = " ";
            textBox2.Text = " ";
            male.Checked = false;
            female.Checked = false;
            richTextBox1.Text = " ";

            SqlConnection connection = new SqlConnection(connectionString);
            string sql = "select std_name,std_fname,std_gender,std_address from student where std_id="+textBox3.Text;
            try
            {
                connection.Open();
                SqlCommand cmd = new SqlCommand(sql, connection);
                SqlDataReader reader = cmd.ExecuteReader(); 
                while (reader.Read())
                {
                    textBox1.Text = reader.GetValue(0).ToString();
                    textBox2.Text = reader.GetValue(1).ToString();
                    if (reader.GetValue(2).ToString().Equals("Male"))
                    {
                        male.Checked = true;
                    }
                    else
                    {

                        female.Checked = true;
                    }
                    richTextBox1.Text = reader.GetValue(3).ToString();

                }
               

            }
            catch (Exception)
            {
                MessageBox.Show("No Records Were Found");
                throw;
            }
            finally {
                connection.Close();
            }


        }

        private void button1_Click(object sender, EventArgs e)
        {
            Student s = new Student();
            s.sdate = System.DateTime.Now.ToShortDateString();
            s.sfk = Form1.fk_ad;
            s.sname = textBox1.Text;
            s.sfname = textBox2.Text;
            if(male.Checked==true){
                s.sgender = "Male";
            }
            else
            {
                s.sgender = "female";
            }
            s.saddress = richTextBox1.Text;
            s.s_id = Convert.ToInt32(textBox3.Text);
            update u = new update();
            string msg = u.update_srecord(s);
            MessageBox.Show(msg);

        }
    }
}
