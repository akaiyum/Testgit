﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace WindowsFormsApplication6
{
    public partial class fessubmission : Form
    {
        private string connectionString =
               @"server = .\sqlexpress; database = OOPDB40; integrated security = true";
        public fessubmission()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection(connectionString);
            string sql = "select s.std_id,s.std_name,sa.sa_id,sa_class_id,sa.sa_year,c.classname,c.fees  from student s inner join student_status sa on sa.sa_st_id=s.std_id inner join classes c on c.class_id=sa.sa_class_id where sa.sa_year='2017' and s.std_id=" + textBox1.Text;
            try
            {
                connection.Open();
                SqlCommand cmd = new SqlCommand(sql, connection);
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {


                    sb_button.Enabled = true;
                    while (reader.Read())
                    {
                        name.Text = "Name: " + reader.GetValue(1).ToString();
                        classes.Text = "Class: " + reader.GetValue(5).ToString();
                        fees.Text = "Fees: " + reader.GetValue(6).ToString();
                        st_id.Text = "Student Id: " + reader.GetValue(2).ToString();


                    }
                    ReturnClass rc = new ReturnClass();
                    string pathquery = rc.scalarReturn("select img_path from student_image where img_fk=" + textBox1.Text);
                    if (pathquery != " ")
                    {
                        pictureBox1.Image = Image.FromFile(pathquery);
                        pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                    }
                    else
                    {
                        pictureBox1.Image = Image.FromFile(@"E:\asp\WindowsFormsApplication6\WindowsFormsApplication6\Resources\profile.png");
                        pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                    }

                    string s = rc.scalarReturn("select COUNT(fee_id) from fees where fee_fk_st_id=" + textBox1.Text + " and monthx=" + System.DateTime.Now.Month.ToString() + "");
                    if (s.Equals("0"))
                    {
                        label2.Text = "Unpaid";

                    }
                    else
                    {
                        label2.Text = "paid";

                    }


                }
                else {

                    MessageBox.Show("No Recored were Found");
                    sb_button.Enabled = false;
                }


            }
            catch (Exception)
            {
                MessageBox.Show("No Records Were Found");

            }
            finally
            {
                connection.Close();
            }


            


        }

        private void fessubmission_Load(object sender, EventArgs e)
        {
            string q = "select s.std_id,sa.sa_st_id,f.fee_id,s.std_name,sa.sa_year,f.dayx+'/'+f.monthx as PaidDate,f.fee_amount from student s inner join student_status sa on s.std_id=sa.sa_st_id inner join fees f on sa.sa_id=f.fee_id where sa.sa_year='2018'";
            view_class v = new view_class(q);
            dataGridView1.DataSource = v.showrecord();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        

        

        
    }
}
