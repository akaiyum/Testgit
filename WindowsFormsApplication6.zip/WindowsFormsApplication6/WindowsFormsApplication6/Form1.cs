﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication6
{
    public partial class Form1 : Form
    {
        public static string fk_ad;
        public Form1()
        {
            InitializeComponent();
        }

       


        private void Login(object sender, EventArgs e)
        {
            string user = textBox1.Text;
            string pass = textBox2.Text;
            string userdb, passdb;
            ReturnClass rs = new ReturnClass();
            userdb = rs.scalarReturn("select COUNT(ad_id) from adminstrator where ad_name='" + user + "'");
            if (userdb.Equals("0"))
            {
                MessageBox.Show("Invalid User Name!");
            }
            else {

                passdb =rs.scalarReturn("select ad_password from adminstrator where ad_name='"+user+"'");
                if (passdb.Equals(pass))
                {
                    fk_ad = rs.scalarReturn("select ad_id from adminstrator where ad_name='" + user + "'");
                    Form2 f = new Form2();
                    f.Show();
                }
                else {
                    MessageBox.Show("Invalid password");
                }
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
