﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace WindowsFormsApplication6
{
    class Delete
    {

        private string connectionString =
               @"server = .\sqlexpress; database = OOPDB40; integrated security = true";
        public string delete_srecord(string id)
        {
            string msg = " ";
            SqlConnection conn = new SqlConnection(connectionString);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("delete_student", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@std_id", SqlDbType.Int).Value = id;
                

                cmd.ExecuteNonQuery();
                msg = "Data Successfully Deleted!";
            }
            catch (Exception)
            {
                msg = "Data is not Successfully Deleted!";
                throw;

            }
            finally
            {
                conn.Close();
            }
            return msg;
        }//method end ....


    }
}
