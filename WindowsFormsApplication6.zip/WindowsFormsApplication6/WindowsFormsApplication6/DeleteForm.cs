﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace WindowsFormsApplication6
{
    public partial class DeleteForm : Form
    {
        private string connectionString =
              @"server = .\sqlexpress; database = OOPDB40; integrated security = true";
        public DeleteForm()
        {
            InitializeComponent();
        }

        private void textBox3_KeyUp(object sender, KeyEventArgs e)
        {
            textBox1.Text = " ";
            textBox2.Text = " ";
            male.Checked = false;
            female.Checked = false;
            richTextBox1.Text = " ";

            SqlConnection connection = new SqlConnection(connectionString);
            string sql = "select std_name,std_fname,std_gender,std_address from student where std_id=" + textBox3.Text;
            try
            {
                connection.Open();
                SqlCommand cmd = new SqlCommand(sql, connection);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    textBox1.Text = reader.GetValue(0).ToString();
                    textBox2.Text = reader.GetValue(1).ToString();
                    if (reader.GetValue(2).ToString().Equals("Male"))
                    {
                        male.Checked = true;
                    }
                    else
                    {

                        female.Checked = true;
                    }
                    richTextBox1.Text = reader.GetValue(3).ToString();

                }


            }
            catch (Exception)
            {
                MessageBox.Show("No Records Were Found");
                
            }
            finally
            {
                connection.Close();
            }



            ReturnClass rc = new ReturnClass();
            string pathquery = rc.scalarReturn("select img_path from student_image where img_fk=" + textBox3.Text);
            if (pathquery != " ")
            {
                pictureBox1.Image = Image.FromFile(pathquery);
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else
            {
                pictureBox1.Image = Image.FromFile(@"E:\asp\WindowsFormsApplication6\WindowsFormsApplication6\Resources\profile.png");
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            }



            







        }

        private void button1_Click(object sender, EventArgs e)
        {
            Delete d = new Delete();
            string msg = d.delete_srecord(textBox3.Text);
            MessageBox.Show(msg);

        }
    }
}
