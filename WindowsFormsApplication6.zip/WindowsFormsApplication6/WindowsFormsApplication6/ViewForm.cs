﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication6
{
    public partial class ViewForm : Form
    {
        public ViewForm()
        {
            InitializeComponent();
        }

        private void ViewForm_Load(object sender, EventArgs e)
        {
            string q = "select s.std_id as 'Id',s.std_name as 'Name',s.std_fname as 'Father Name',s.std_gender as 'Gender',s.std_address as 'Address',s.std_admissiondate as 'Admissiondate',a.ad_name as 'Admin Name' from student s inner join adminstrator a on a.ad_id=s.std_ad_fk_id";
            view_class v = new view_class(q);
            dataGridView1.DataSource = v.showrecord(); 
        }

        private void textBox1_KeyUp(object sender, KeyEventArgs e)
        {
            string q = "select s.std_id as 'Id',s.std_name as 'Name',s.std_fname as 'Father Name',s.std_gender as 'Gender',s.std_address as 'Address',s.std_admissiondate as 'Admissiondate',a.ad_name as 'Admin Name' from student s inner join adminstrator a on a.ad_id=s.std_ad_fk_id where s.std_name like '" + textBox1.Text + "%'";
            view_class v = new view_class(q);
            dataGridView1.DataSource = v.showrecord();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string q = "select s.std_id as 'Id',s.std_name as 'Name',s.std_fname as 'Father Name',s.std_gender as 'Gender',s.std_address as 'Address',s.std_admissiondate as 'Admissiondate',a.ad_name as 'Admin Name' from student s inner join adminstrator a on a.ad_id=s.std_ad_fk_id where s.std_id=" + textBox2.Text;
            view_class v = new view_class(q);
            dataGridView1.DataSource = v.showrecord();

            ReturnClass rc = new ReturnClass();
            string pathquery = rc.scalarReturn("select img_path from student_image where img_fk=" + textBox2.Text);
            if (pathquery != " ")
            {
                pictureBox1.Image = Image.FromFile(pathquery);
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else
            {
                pictureBox1.Image = Image.FromFile(@"E:\asp\WindowsFormsApplication6\WindowsFormsApplication6\Resources\profile.png");
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
