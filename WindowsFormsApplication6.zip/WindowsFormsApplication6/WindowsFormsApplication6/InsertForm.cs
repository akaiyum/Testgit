﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication6
{
    public partial class InsertForm : Form
    {
        public InsertForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Student s = new Student();
            s.sfk = Form1.fk_ad;
            s.sdate = System.DateTime.Now.ToShortDateString();
            s.sname = textBox1.Text;
            s.sfname = textBox2.Text;
            if(male.Checked==true){
                s.sgender = "Male";
            }
            else if (female.Checked == true)
            {
                s.sgender = "Female";
            }
            else {
                MessageBox.Show("Please select gender!");
            }

            s.saddress = richTextBox1.Text;
            Insert i = new Insert();
            
            MessageBox.Show(i.insert_srecord(s));



            ReturnClass r = new ReturnClass();

            Student_Stutus sa = new Student_Stutus();
            sa.year = System.DateTime.Now.Year.ToString();
            sa.class_id = Convert.ToInt16(comboBox1.SelectedValue.ToString());
            sa.status_student_id = Convert.ToInt32(r.scalarReturn("select MAX(std_id) from student"));
           
            i.insert_student_stutus(sa);

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void male_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void female_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }



        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            open.Filter = "Image Files(*.jpg; *.jpeg; *.gif; *.bmp; *.png)|*.jpg; *.jpeg; *.gif; *.bmp; *.png;";
            if(open.ShowDialog() == DialogResult.OK){
                pictureBox1.Image = new Bitmap(open.FileName);
                textBox3.Text = open.FileName;

            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Student_Image img = new Student_Image();
            img.s_id = Convert.ToInt32(textBox4.Text);
            img.img_path = textBox3.Text;
            Insert i = new Insert();
            i.insert_img(img);

        }

        private void InsertForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'oOPDB40DataSet.classes' table. You can move, or remove it, as needed.
            this.classesTableAdapter.Fill(this.oOPDB40DataSet.classes);

        }

        private void button4_Click(object sender, EventArgs e)
        {
            ReturnClass r = new ReturnClass();
            
            Student_Stutus sa = new Student_Stutus();
            sa.year = System.DateTime.Now.Year.ToString();
            sa.class_id = Convert.ToInt16(comboBox1.SelectedValue.ToString());
            sa.status_student_id = Convert.ToInt32(textBox5.Text);
            Insert i = new Insert();
            i.insert_student_stutus(sa);
        }
    }
}
