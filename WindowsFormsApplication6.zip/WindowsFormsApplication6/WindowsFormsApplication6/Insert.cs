﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace WindowsFormsApplication6
{
    class Insert
    {
        
        private string connectionString =
               @"server = .\sqlexpress; database = OOPDB40; integrated security = true";
        public string insert_srecord(Student s) {
            string msg = " ";
            SqlConnection conn = new SqlConnection(connectionString);
            try {
                conn.Open();
                SqlCommand cmd = new SqlCommand("insert_student", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@std_name", SqlDbType.NVarChar, 20).Value = s.sname;
                cmd.Parameters.Add("@std_fname", SqlDbType.NVarChar, 20).Value = s.sfname;
                cmd.Parameters.Add("@std_gender", SqlDbType.NVarChar, 6).Value = s.sgender;
                cmd.Parameters.Add("@std_address", SqlDbType.NVarChar, 100).Value = s.saddress;
                cmd.Parameters.Add("@std_admissiondate", SqlDbType.NVarChar, 20).Value = s.sdate;
                cmd.Parameters.Add("@std_ad_fk_id", SqlDbType.NVarChar, 20).Value = s.sfk;

                
                cmd.ExecuteNonQuery();
                msg = "Data Successfully Inserted!";
            }catch(Exception){
                msg = "Data is not Successfully Inserted!";
                throw; 
                
            }
            finally{
                conn.Close();
            }
            return msg;
        }//method end ....
        public void insert_img(Student_Image img) {
            SqlConnection conn = new SqlConnection(connectionString);
            try
            {
                SqlCommand cmd = new SqlCommand("insert_student_img", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@img_path", SqlDbType.NVarChar).Value = img.img_path;
                cmd.Parameters.Add("@img_fk", SqlDbType.Int).Value = img.s_id;


                conn.Open();
                cmd.ExecuteNonQuery();

                MessageBox.Show("Data record has been inserted successfully....");

            }
            catch (Exception)
            {
                MessageBox.Show("Data is not inserted!");
            }
            finally {
                conn.Close();
            }
        
        }


        public void insert_student_stutus(Student_Stutus sa)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            try
            {
                SqlCommand cmd = new SqlCommand("insert_student_status", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@sa_st_id", SqlDbType.Int).Value = sa.status_student_id;
                cmd.Parameters.Add("@sa_class_id", SqlDbType.Int).Value = sa.class_id;
                cmd.Parameters.Add("@sa_year", SqlDbType.NVarChar, 5).Value = sa.year;


                conn.Open();
                cmd.ExecuteNonQuery();

                MessageBox.Show("Data record has been inserted successfully....");

            }
            catch (Exception)
            {
                MessageBox.Show("Data is not inserted!");
            }
            finally
            {
                conn.Close();
            }

        }// end method



        public void insert_fees(Student_Stutus sa, string id)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            try
            {
                SqlCommand cmd = new SqlCommand("insert_fees", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@fee_amount", SqlDbType.Float).Value = sa.class_fee;
                cmd.Parameters.Add("@fee_fk_st_id", SqlDbType.Int).Value = id;
                cmd.Parameters.Add("@monthx", SqlDbType.NVarChar).Value = System.DateTime.Now.Month.ToString();
                cmd.Parameters.Add("@sa_fk_id", SqlDbType.Int).Value = sa.status_student_id;
                cmd.Parameters.Add("@dayx", SqlDbType.NVarChar).Value = System.DateTime.Now.Day.ToString();


                conn.Open();
                cmd.ExecuteNonQuery();

                MessageBox.Show("Data record has been inserted successfully....");

            }
            catch (Exception)
            {
                MessageBox.Show("Data is not inserted!");
            }
            finally
            {
                conn.Close();
            }

        }// end method

        



    }
}
