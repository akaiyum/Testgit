﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;

namespace WindowsFormsApplication6
{
    class ReturnClass
    {
        string connectionString =
               @"server = .\sqlexpress; database = OOPDB40; integrated security = true";
        public string scalarReturn(string q)
        {
            string s=" ";

            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();
            try
            {
                SqlCommand cmd = new SqlCommand(q, conn);
                s = cmd.ExecuteScalar().ToString();

            }
            catch (Exception)
            {
                s =" ";
                
            }

            
            return s;

        }
    }
}
