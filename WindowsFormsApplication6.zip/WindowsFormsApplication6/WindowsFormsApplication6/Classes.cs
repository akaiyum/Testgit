﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsFormsApplication6
{
    class Classes
    {
        public int class_id { get; set; }
        public string class_name { get; set; }
        public string class_fee { get; set; }
    }
}
