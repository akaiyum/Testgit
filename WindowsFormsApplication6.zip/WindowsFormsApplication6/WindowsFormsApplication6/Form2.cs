﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication6
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            InsertForm In = new InsertForm();
            In.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            UpdateForm Up = new UpdateForm();
            Up.Show();
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            DeleteForm De = new DeleteForm();
            De.Show();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            ViewForm Ve = new ViewForm();
            Ve.Show();
        }


    }
}
