﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsFormsApplication6
{
    class Student
    {
        public int s_id { get; set; }
        public string sname { get; set; }
        public string sfname { get; set; }
        public string sgender { get; set; }
        public string saddress { get; set; }
        public string sdate { get; set; }
        public string sfk { get; set; }
        
    }
}
